import xbmcaddon

MainBase = 'https://vidatv.xyz'
addon = xbmcaddon.Addon('vida')