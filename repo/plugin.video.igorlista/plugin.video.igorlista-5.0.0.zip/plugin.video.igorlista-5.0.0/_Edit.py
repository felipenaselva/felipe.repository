import xbmcaddon

MainBase = 'http://bit.ly/igorlista5_0'
addon = xbmcaddon.Addon('plugin.video.igorlista')