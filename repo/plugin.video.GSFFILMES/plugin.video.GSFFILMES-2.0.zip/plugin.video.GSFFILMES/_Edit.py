import xbmcaddon

MainBase = 'https://pastebin.com/raw/MRbzivXg'
addon = xbmcaddon.Addon('plugin.video.GSF FILMES')