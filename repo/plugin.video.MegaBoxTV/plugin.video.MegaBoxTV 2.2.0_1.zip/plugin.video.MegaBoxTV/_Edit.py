import xbmcaddon
MainBase = 'https://goo.gl/c00o9q'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV')