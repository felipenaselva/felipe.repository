# coding: utf-8
__author__ = 'mancuniancol'

data = '''

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="auto">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Come and download frozen 2013 absolutely for free. Fast downloads."/>
    <meta name="robots" content="noindex" rel="usearch"/>
    <title>Download frozen 2013 Torrents  - Kickass Torrents</title>
    <link rel="stylesheet" type="text/css" href="//kastatic.com/all-4d03bb7.css" charset="utf-8" />
    <link rel="shortcut icon" href="//kastatic.com/images/favicon.ico" />


    <link rel="apple-touch-icon" href="//kastatic.com/images/apple-touch-icon.png" />

    <!--[if IE 7]>
    <link href="//kastatic.com/css/ie7-4d03bb7.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if IE 8]>
    <link href="//kastatic.com/css/ie8.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if lt IE 9]>
    <script src="//kastatic.com/js/html5.min-4d03bb7.js" type="text/javascript"></script>
    <![endif]-->

    <!--[if gte IE 9]>
    <link href="//kastatic.com/css/ie9-4d03bb7.css" rel="stylesheet" type="text/css"/>
    <![endif]-->
    <script type="text/javascript">
        +function(S,p,a,r,e,C,l,i,c,k)
        { S[r]=S[r]||[];S[e]||(S[e]=function(){
        S[r].push(Array.prototype.slice.call(arguments)) });
        i=p.createElement(a);c=p.getElementsByTagName(a)[0];
        i.src=C;i.async=true;c.parentNode.insertBefore(i,c)}
        (window,document,'script','_scq','sc', '//a.kickass.to/sc-4d03bb7.js');

        sc('setHost', 'a.kickass.to');
        sc('setAccount', '_b894d6cb1e370fb9ad89f8d6d99eeb33');
            var kat = {
            release_id: '4d03bb7',
            detect_lang: 0,
            spare_click: 1,
            mobile: false
        };
    </script>
    <script src="//kastatic.com/js/all-4d03bb7.js" type="text/javascript"></script>
    <link rel="alternate" type="application/rss+xml" title="Subscribe to RSS feed" href="http://kat.cr/usearch/frozen%202013/?rss=1"/>
        <meta name="verify-v1" content="YccN/iP28SifHNEFY6u92i0ou3tAegQAIk2OyOJLp1s="/>
    <meta name="y_key" content="f0b40c3f5fee758f"/>
    <meta name="google-site-verification" content="C1rNEC4fJIvFoyyccMV2PbuqX3P-SFtlD2MNZ9D2uy0" />
    <link rel="search" type="application/opensearchdescription+xml" title="KickassTorrents Torrent Search" href="/opensearch.xml"/>
    <meta property="fb:app_id" content="123694587642603"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
</head>
<body>
<div id="wrapper">
    <div id="wrapperInner">
<div  data-sc-slot="_60318cd4e8d28f6fb76fe34e9bd9c498"></div>
<div  data-sc-slot="_39ecb76dd457e5ac33776fdf11500d56"></div>
    <div id="logindiv"></div>
    <header>
	<nav id="menu">
		<a href="/" id="logo"></a>
		<a href="#" id="showHideSearch"><i class="ka ka-zoom"></i></a>
		<div id="torrentSearch">
			<form action="/usearch/" method="get" id="searchform" accept-charset="utf-8" onsubmit="return doSearch(this.q.value);">
				<input id="contentSearch" class="input-big" type="text" name="q" value="frozen 2013" autocomplete="off" placeholder="Search query" /><div id="searchTool"><a title="Advanced search" href="/advanced/?q=frozen 2013" class="ajaxLink"><i class="ka ka-settings"></i></a><button title="search" type="submit" value="" onfocus="this.blur();" onclick="this.blur();"><i class="ka ka-search"></i></button></div>
			</form>
		</div>
        <div  data-sc-slot="_277923e5f9d753c5b0630c28e641790c"></div>
		<ul id="navigation">

			<li> <a href="/browse/"> <i class="ka ka-torrent"></i><span class="menuItem">browse</span></a>
				<ul class="dropdown dp-middle dropdown-msg upper">

						<li class="topMsg"><a href="/new/"><i class="ka ka16 ka-torrent"></i>latest</a></li>
										<li class="topMsg"><a href="/movies/"><i class="ka ka16 ka-movie lower"></i>Movies</a></li>
					<li class="topMsg"><a href="/tv/"><i class="ka ka16 ka-movie lower"></i>TV</a></li>
					<li class="topMsg"><a href="/music/"><i class="ka ka16 ka-music-note lower"></i>Music</a></li>
					<li class="topMsg"><a href="/games/"><i class="ka ka16 ka-settings lower"></i>Games</a></li>
					<li class="topMsg"><a href="/books/"><i class="ka ka16 ka-bookmark"></i>Books</a></li>
					<li class="topMsg"><a href="/applications/"><i class="ka ka16 ka-settings lower"></i>Apps</a></li>
					<li class="topMsg"><a href="/anime/"><i class="ka ka16 ka-movie lower"></i>Anime</a></li>
					<li class="topMsg"><a href="/other/"><i class="ka ka16 ka-torrent"></i>Other</a></li>
											<li class="topMsg"><a href="/xxx/"><i class="ka ka16 ka-delete"></i>XXX</a></li>
									</ul>
			</li>
			</li>
			<li><a data-nop href="/community/"> <i class="ka ka-community"></i><span class="menuItem">Community</span></a>
			<li><a data-nop href="/blog/"><i class="ka ka-rss lower"></i><span class="menuItem">Blog</span></a></li>
			<li><a data-nop href="/faq/"><i class="ka ka-faq lower"></i><span class="menuItem">FAQ</span></a></li>
			</li>

			<li> <a data-nop href="/auth/login/" class="ajaxLink"><i class="ka ka-user"></i><span class="menuItem">Register / Sign In</span></a></li>
		</ul>
	</nav>
</header>

<div class="pusher"></div>
<div class="mainpart">


<table width="100%" cellspacing="0" cellpadding="0" class="doublecelltable" id="mainSearchTable">
	<tr>
		<td width="100%">
							<div class="spareBlock hzSpare">
    <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
    <div  data-sc-slot="_b77c3599a877a4e9d6097b83ec9f23bb" data-sc-params="{ 'searchQuery': 'frozen 2013' }"></div>
</div>

										<div class="tabs">
	<ul class="tabNavigation">
		<li><a class="selectedTab" href="/search/frozen 2013/"><span>Sponsored Links</span></a></li>
	</ul>
	<hr class="tabsSeparator"/>
</div>
<div  data-sc-slot="_c039297fb3d18cf107e21460970475f0"></div>
<br /><br />

						            								        		    <h1><a itemprop="url" class="plain" href="/frozen-i2294629/">Frozen</a></h1>
				<div class="torrentMediaInfo">
    <a class="movieCover" href="/frozen-i2294629/"><img src="//yuq.me/movies/22/946/2294629.jpg" /></a>
    <div class="dataList">
        <ul class="block overauto botmarg0">
            <li><strong>IMDb link:</strong> <a class="plain" href="http://www.imdb.com/title/tt2294629/">2294629</a></li>
                        <li><strong>IMDb rating:</strong> 7.6 (390,405 votes) </li>
                                    <li><strong>RottenTomatoes:</strong> <span class="rottentomatoes positive" title="fresh!"></span>89% <span class="rottenaudience positive" title="audience like it!"></span>86% </li>
                                        <li><strong>Watch on <a data-nop target="_blank" href="https://www.solarmovie.ph">Solarmovie</a>:</strong> <a data-nop target="_blank" href="https://www.solarmovie.ph/watch-frozen-2013.html">Frozen</a></li>
                                    <li><strong>Genres:</strong>  <a class="plain" href="/movies/genre/animation/"><span>Animation</span></a>,  <a class="plain" href="/movies/genre/adventure/"><span>Adventure</span></a>,  <a class="plain" href="/movies/genre/family/"><span>Family</span></a>,  <a class="plain" href="/movies/genre/comedy/"><span>Comedy</span></a>,  <a class="plain" href="/movies/genre/fantasy/"><span>Fantasy</span></a>,  <a class="plain" href="/movies/genre/musical/"><span>Musical</span></a> </li>
                    </ul>
        <ul>
                    <li><a href="/bookmarks/add/movie/2294629/" class="ajaxLink kaButton smallButton normalText"><i class="ka ka-bookmark"></i> add <strong>Frozen</strong> to bookmarks</a></li>
                                <li><strong>Release date:</strong> 27 November 2013</li>
                                <li><strong>Writers:</strong> Jennifer Lee (screenplay), Hans Christian Andersen (story), Chris Buck (story), Jennifer Lee (story), Shane Morris (story)</li>

                                                </ul>
                <div class="floatleft width100perc botmarg10px"><strong>Cast:</strong>  <span><a href="/movies/actor/kristen-bell-a0068338/">Kristen Bell</a></span>,              <span><a href="/movies/actor/idina-menzel-a0579953/">Idina Menzel</a></span>,              <span><a href="/movies/actor/josh-gad-a1265802/">Josh Gad</a></span>,              <span><a href="/movies/actor/jonathan-groff-a2676147/">Jonathan Groff</a></span> and others             </div>
                        <div class="floatleft width100perc botmarg10px">
            <strong>Summary:</strong>
                <div id="summary">
<p class="accentbox botmarg10px">
    When a princess with the power to turn things into ice curses her home in infinite winter, her sister, Anna teams up with a mountain man, his playful reindeer, and a snowman to change the weather condition.<br />
    </p>
<strong><small>Written by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_9"><a class="plain" href="/user/Thhaque/">Thhaque</a></span><span title="Reputation" class="repValue positive">407.84K</span></span></small></strong>




    </div>

        </div>
        <div  data-sc-slot="_16b9d77edbc49edc5a7a757cde4dfe28" data-sc-params="{ 'movie_name': 'Frozen' }"></div>
                <div class="pages marg0 floatleft"> <strong class="botpad5px block">Available in versions:</strong> <a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#1080p">1080p</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#720p">720p</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#Blu-Ray">Blu-Ray</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#BDRip">BDRip</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#HDRiP">HDRiP</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#DVD">DVD</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#DVDRip">DVDRip</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#x264">x264</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#VCD">VCD</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#Screener">Screener</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#TeleSync">TeleSync</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#Cam">Cam</a> </div>
            </div>
    <!-- div class="dataList" -->
</div>



	        <div class="tabs">
	<ul class="tabNavigation">
        <li>
            <a class="darkButton selectedTab" href="/usearch/frozen%202013/"><span>All</span></a>
        </li>
        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:movies/"><span>Movies <i class="menuValue">386</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:tv/"><span>TV <i class="menuValue">5</i></span></a>
        </li>                <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:music/"><span>Music <i class="menuValue">24</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:books/"><span>Books <i class="menuValue">3</i></span></a>
        </li>        <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:games/"><span>Games <i class="menuValue">5</i></span></a>
        </li>                <li>
            <a rel="nofollow" class="darkButton" href="/usearch/frozen%202013 category:xxx/"><span>XXX <i class="menuValue">1</i></span></a>
        </li>
	</ul>
	<hr class="tabsSeparator"/>
</div>

			<div><h2>									frozen 2013							<span>  results 1-25 from 425</span>  <a data-nop class="ka ka16 ka-rss normalText rsssign ka-red" target="_blank" href="http://kat.cr/usearch/frozen%202013/?rss=1" title="rss"></a></h2>


	<table cellpadding="0" cellspacing="0" class="data" style="width: 100%">
		<tr class="firstr">
			<th class="width100perc nopad">torrent name</th>
						<th class="center"><a href="/usearch/frozen%202013/?field=size&sorder=desc" rel="nofollow">size</a></th>
						<th class="center"><span class="files"><a href="/usearch/frozen%202013/?field=files_count&sorder=desc" rel="nofollow">files</a></span></th>
						<th class="center"><span><a href="/usearch/frozen%202013/?field=time_add&sorder=desc" rel="nofollow">age</a></span></th>
						<th class="center"><span class="seed"><a href="/usearch/frozen%202013/?field=seeders&sorder=desc" rel="nofollow">seed</a></span></th>
						<th class="lasttd nobr center"><a href="/usearch/frozen%202013/?field=leechers&sorder=desc" rel="nofollow">leech</a></th>
</tr>
						<tr class="odd" id="torrent_frozen_20138817152">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8817152,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-brrip-x264-yify-t8817152.html#comment">854 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20720p%20BrRip%20x264%20-%20YIFY', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:25B4CD46E389E96F80EE42E418CD89D3A65ECD66&dn=frozen+2013+720p+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:25B4CD46E389E96F80EE42E418CD89D3A65ECD66&dn=frozen+2013+720p+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/25B4CD46E389E96F80EE42E418CD89D3A65ECD66.torrent?title=[kat.cr]frozen.2013.720p.brrip.x264.yify" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="torType filmType"></a>
                <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) 720p BrRip x264 - YIFY</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/YIFY/">YIFY</a> in <span id="cat_8817152"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">805.48 <span>MB</span></td>
			<td class="center">2</td>
			<td class="center" title="27 Feb 2014, 06:30">1&nbsp;year</td>
			<td class="green center">1478</td>
			<td class="red lasttd center">132</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138821806">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8821806,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html#comment">2 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20MULTi%201080p%20BluRay%20x264-ROUGH', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:B53C3AA969C13DBC58FE9394EA3A553C08839238&dn=frozen+2013+multi+1080p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:B53C3AA969C13DBC58FE9394EA3A553C08839238&dn=frozen+2013+multi+1080p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/B53C3AA969C13DBC58FE9394EA3A553C08839238.torrent?title=[kat.cr]frozen.2013.multi.1080p.bluray.x264.rough" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="torType filmType"></a>
                <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="cellMainLink"><strong class="red">Frozen</strong> <strong class="red">2013</strong> MULTi 1080p BluRay x264-ROUGH</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_8821806"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">6.56 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="28 Feb 2014, 12:00">1&nbsp;year</td>
			<td class="green center">198</td>
			<td class="red lasttd center">22</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138893033">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8893033,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html#comment">19 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Il%20Regno%20Di%20Ghiaccio%202013%20iTALiAN%20AC3%20DUAL%201080p%20BrRiP%20x264-TrTd_TeaM', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:A794083F24D2E20C9E9C935B32CC880F1E2A064E&dn=frozen+il+regno+di+ghiaccio+2013+italian+ac3+dual+1080p+brrip+x264+trtd+team&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A794083F24D2E20C9E9C935B32CC880F1E2A064E&dn=frozen+il+regno+di+ghiaccio+2013+italian+ac3+dual+1080p+brrip+x264+trtd+team&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/A794083F24D2E20C9E9C935B32CC880F1E2A064E.torrent?title=[kat.cr]frozen.il.regno.di.ghiaccio.2013.italian.ac3.dual.1080p.brrip.x264.trtd.team" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="torType filmType"></a>
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="cellMainLink"><strong class="red">Frozen</strong> Il Regno Di Ghiaccio <strong class="red">2013</strong> iTALiAN AC3 DUAL 1080p BrRiP x264-TrTd_TeaM</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ignazio71/">ignazio71</a> in <span id="cat_8893033"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.48 <span>GB</span></td>
			<td class="center">5</td>
			<td class="center" title="18 Mar 2014, 17:32">1&nbsp;year</td>
			<td class="green center">181</td>
			<td class="red lasttd center">40</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138819093">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8819093,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html#comment">16 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20FRENCH%20720p%20BluRay%20x264-ROUGH', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:FDBE9CABF1604205AF1556A2E4D3A336079EE0B1&dn=frozen+2013+french+720p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:FDBE9CABF1604205AF1556A2E4D3A336079EE0B1&dn=frozen+2013+french+720p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/FDBE9CABF1604205AF1556A2E4D3A336079EE0B1.torrent?title=[kat.cr]frozen.2013.french.720p.bluray.x264.rough" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="torType filmType"></a>
                <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="cellMainLink"><strong class="red">Frozen</strong> <strong class="red">2013</strong> FRENCH 720p BluRay x264-ROUGH</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_8819093"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.28 <span>GB</span></td>
			<td class="center">2</td>
			<td class="center" title="27 Feb 2014, 18:00">1&nbsp;year</td>
			<td class="green center">191</td>
			<td class="red lasttd center">17</td>
			</tr>
						<tr class="odd" id="torrent_frozen_201310248473">
            <td>
            <div class="iaconbox center floatright">
                				<a class="icon16" href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20BDRip%20XviD%20ENG-ITA%20Ac3%20subs%20-%20Il%20Regno%20Di%20Ghiaccio', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:E2167529F2A86ABD6F8F32C98B82450D88E38326&dn=frozen+2013+bdrip+xvid+eng+ita+ac3+subs+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:E2167529F2A86ABD6F8F32C98B82450D88E38326&dn=frozen+2013+bdrip+xvid+eng+ita+ac3+subs+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/E2167529F2A86ABD6F8F32C98B82450D88E38326.torrent?title=[kat.cr]frozen.2013.bdrip.xvid.eng.ita.ac3.subs.il.regno.di.ghiaccio" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="torType filmType"></a>
                <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) BDRip XviD ENG-ITA Ac3 subs - Il Regno Di Ghiaccio</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ShivaShanti/">ShivaShanti</a> in <span id="cat_10248473"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.75 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="20 Feb 2015, 12:14">11&nbsp;months</td>
			<td class="green center">161</td>
			<td class="red lasttd center">27</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138927714">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8927714,0" class="icommentjs kaButton smallButton rightButton" href="/kraina-lodu-frozen-2013-minihd-1080p-ac3-bdrip-x264-gixerk9-dubbing-pl-t8927714.html#comment">7 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/kraina-lodu-frozen-2013-minihd-1080p-ac3-bdrip-x264-gixerk9-dubbing-pl-t8927714.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Kraina%20Lodu%20-%20Frozen%20%282013%29%20%5BminiHD.1080p.AC3.BDRip.x264-gixerk9%5D%20%5BDubbing%20PL%5D', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:5D07B5D3458D659209E39A4AA7C4BD20FF9529F5&dn=kraina+lodu+frozen+2013+minihd+1080p+ac3+bdrip+x264+gixerk9+dubbing+pl&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:5D07B5D3458D659209E39A4AA7C4BD20FF9529F5&dn=kraina+lodu+frozen+2013+minihd+1080p+ac3+bdrip+x264+gixerk9+dubbing+pl&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/5D07B5D3458D659209E39A4AA7C4BD20FF9529F5.torrent?title=[kat.cr]kraina.lodu.frozen.2013.minihd.1080p.ac3.bdrip.x264.gixerk9.dubbing.pl" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/kraina-lodu-frozen-2013-minihd-1080p-ac3-bdrip-x264-gixerk9-dubbing-pl-t8927714.html" class="torType filmType"></a>
                <a href="/kraina-lodu-frozen-2013-minihd-1080p-ac3-bdrip-x264-gixerk9-dubbing-pl-t8927714.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/kraina-lodu-frozen-2013-minihd-1080p-ac3-bdrip-x264-gixerk9-dubbing-pl-t8927714.html" class="cellMainLink">Kraina Lodu - <strong class="red">Frozen</strong> (<strong class="red">2013</strong>) [miniHD.1080p.AC3.BDRip.x264-gixerk9] [Dubbing PL]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/gixerk9/">gixerk9</a> in <span id="cat_8927714"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.77 <span>GB</span></td>
			<td class="center">2</td>
			<td class="center" title="27 Mar 2014, 14:07">1&nbsp;year</td>
			<td class="green center">95</td>
			<td class="red lasttd center">1</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138881471">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8881471,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-3d-brrip-x264-yify-t8881471.html#comment">154 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%203D%20BrRip%20x264%20-%20YIFY', 'extension': 'mp4', 'magnet': 'magnet:?xt=urn:btih:06C0D76D3B5AB230FCF2584FB381D529C6FABD2F&dn=frozen+2013+3d+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:06C0D76D3B5AB230FCF2584FB381D529C6FABD2F&dn=frozen+2013+3d+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/06C0D76D3B5AB230FCF2584FB381D529C6FABD2F.torrent?title=[kat.cr]frozen.2013.3d.brrip.x264.yify" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="torType filmType"></a>
                <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) 3D BrRip x264 - YIFY</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/YIFY/">YIFY</a> in <span id="cat_8881471"><strong><a href="/movies/">Movies</a> > <a href="/3d-movies/">3D Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.63 <span>GB</span></td>
			<td class="center">2</td>
			<td class="center" title="15 Mar 2014, 13:20">1&nbsp;year</td>
			<td class="green center">84</td>
			<td class="red lasttd center">17</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138903675">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8903675,0" class="icommentjs kaButton smallButton rightButton" href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html#comment">8 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Disney%27s%20Frozen%20%282013%29%20Eng%20NL%20Audio%20Eng%20NL%20Sub%20BR2DVD-NLU002', 'extension': 'vob', 'magnet': 'magnet:?xt=urn:btih:17EA7E292B54A62069594D061D58C8D83CA9B83E&dn=disney+s+frozen+2013+eng+nl+audio+eng+nl+sub+br2dvd+nlu002&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:17EA7E292B54A62069594D061D58C8D83CA9B83E&dn=disney+s+frozen+2013+eng+nl+audio+eng+nl+sub+br2dvd+nlu002&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/17EA7E292B54A62069594D061D58C8D83CA9B83E.torrent?title=[kat.cr]disney.s.frozen.2013.eng.nl.audio.eng.nl.sub.br2dvd.nlu002" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="torType filmType"></a>
                <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="cellMainLink">Disney's <strong class="red">Frozen</strong> (<strong class="red">2013</strong>) Eng NL Audio Eng NL Sub BR2DVD-NLU002</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/NLUPPER002/">NLUPPER002</a> in <span id="cat_8903675"><strong><a href="/movies/">Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">4.36 <span>GB</span></td>
			<td class="center">16</td>
			<td class="center" title="21 Mar 2014, 12:44">1&nbsp;year</td>
			<td class="green center">78</td>
			<td class="red lasttd center">3</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138903808">
            <td>
            <div class="iaconbox center floatright">
                				<a class="icon16" href="/frozen-el-reino-del-hielo-2013-hdrip-xvid-ac3-castellano-t8903808.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen.%20El%20reino%20del%20hielo%20%282013%29%20%5BHDrip-XviD-AC3%5D%5BCastellano%5D', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:4DEE30E9EDD884750ACC36CBD13FC27F6038E889&dn=frozen+el+reino+del+hielo+2013+hdrip+xvid+ac3+castellano&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:4DEE30E9EDD884750ACC36CBD13FC27F6038E889&dn=frozen+el+reino+del+hielo+2013+hdrip+xvid+ac3+castellano&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/4DEE30E9EDD884750ACC36CBD13FC27F6038E889.torrent?title=[kat.cr]frozen.el.reino.del.hielo.2013.hdrip.xvid.ac3.castellano" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-el-reino-del-hielo-2013-hdrip-xvid-ac3-castellano-t8903808.html" class="torType filmType"></a>
                <a href="/frozen-el-reino-del-hielo-2013-hdrip-xvid-ac3-castellano-t8903808.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-el-reino-del-hielo-2013-hdrip-xvid-ac3-castellano-t8903808.html" class="cellMainLink"><strong class="red">Frozen</strong>. El reino del hielo (<strong class="red">2013</strong>) [HDrip-XviD-AC3][Castellano]</a>

                                                <span class="font11px lightgrey block">
                in <span id="cat_8903808"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.47 <span>GB</span></td>
			<td class="center">2</td>
			<td class="center" title="21 Mar 2014, 13:51">1&nbsp;year</td>
			<td class="green center">65</td>
			<td class="red lasttd center">4</td>
			</tr>
						<tr class="even" id="torrent_frozen_201310064281">
            <td>
            <div class="iaconbox center floatright">
                <a rel="10064281,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html#comment">5 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20BDRip%201080p%20ENG-ITA%20x265%20BluRay%20-%20Il%20Regno%20Di%20Ghiaccio', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:AEE029C8D3D0A76D8384376E6C126C2EFE885BBC&dn=frozen+2013+bdrip+1080p+eng+ita+x265+bluray+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:AEE029C8D3D0A76D8384376E6C126C2EFE885BBC&dn=frozen+2013+bdrip+1080p+eng+ita+x265+bluray+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/AEE029C8D3D0A76D8384376E6C126C2EFE885BBC.torrent?title=[kat.cr]frozen.2013.bdrip.1080p.eng.ita.x265.bluray.il.regno.di.ghiaccio" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="torType filmType"></a>
                <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) BDRip 1080p ENG-ITA x265 BluRay - Il Regno Di Ghiaccio</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ShivaShanti/">ShivaShanti</a> in <span id="cat_10064281"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">4.08 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="11 Jan 2015, 11:41">1&nbsp;year</td>
			<td class="green center">51</td>
			<td class="red lasttd center">19</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138517377">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8517377,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html#comment">188 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%5B2013%5D%20DVDScr%20XviD-SaM%5BETRG%5D', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:6B03287DA83A543190D1ECFA947632351F5F0B33&dn=frozen+2013+dvdscr+xvid+sam+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:6B03287DA83A543190D1ECFA947632351F5F0B33&dn=frozen+2013+dvdscr+xvid+sam+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/6B03287DA83A543190D1ECFA947632351F5F0B33.torrent?title=[kat.cr]frozen.2013.dvdscr.xvid.sam.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="torType filmType"></a>
                <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="cellMainLink"><strong class="red">Frozen</strong> [<strong class="red">2013</strong>] DVDScr XviD-SaM[ETRG]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SaM/">SaM</a> in <span id="cat_8517377"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">708.3 <span>MB</span></td>
			<td class="center">5</td>
			<td class="center" title="07 Jan 2014, 23:28">2&nbsp;years</td>
			<td class="green center">48</td>
			<td class="red lasttd center">12</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138516976">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8516976,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html#comment">128 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20720p%20DVDSCR%20XViD%20AC3-HuMPDaY', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:8631A6C1FEE556246A798946A638D2661C634946&dn=frozen+2013+720p+dvdscr+xvid+ac3+humpday&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:8631A6C1FEE556246A798946A638D2661C634946&dn=frozen+2013+720p+dvdscr+xvid+ac3+humpday&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/8631A6C1FEE556246A798946A638D2661C634946.torrent?title=[kat.cr]frozen.2013.720p.dvdscr.xvid.ac3.humpday" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="torType filmType"></a>
                <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="cellMainLink"><strong class="red">Frozen</strong> <strong class="red">2013</strong> 720p DVDSCR XViD AC3-HuMPDaY</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ChrisDen/">ChrisDen</a> in <span id="cat_8516976"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.36 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="07 Jan 2014, 21:00">2&nbsp;years</td>
			<td class="green center">48</td>
			<td class="red lasttd center">5</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20139429766">
            <td>
            <div class="iaconbox center floatright">
                				<a class="icon16" href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t9429766.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%5BBluRay%20Rip%5D%5BAC3%205.1%20Espa%C3%B1ol%20Castellano%5D%5B2013%5D', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:93590ABAFAB17F2C742B863A3D601B67A556EF68&dn=frozen+bluray+rip+ac3+5+1+espa%C3%B1ol+castellano+2013&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:93590ABAFAB17F2C742B863A3D601B67A556EF68&dn=frozen+bluray+rip+ac3+5+1+espa%C3%B1ol+castellano+2013&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/93590ABAFAB17F2C742B863A3D601B67A556EF68.torrent?title=[kat.cr]frozen.bluray.rip.ac3.5.1.espa%C3%B1ol.castellano.2013" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t9429766.html" class="torType filmType"></a>
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t9429766.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t9429766.html" class="cellMainLink"><strong class="red">Frozen</strong> [BluRay Rip][AC3 5.1 Español Castellano][<strong class="red">2013</strong>]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/hkcrew/">hkcrew</a> in <span id="cat_9429766"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.86 <span>GB</span></td>
			<td class="center">3</td>
			<td class="center" title="08 Aug 2014, 19:08">1&nbsp;year</td>
			<td class="green center">44</td>
			<td class="red lasttd center">3</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138830076">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8830076,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-il-regno-di-ghiaccio-2013-italian-md-dual-1080p-brrip-x264-trtd-team-t8830076.html#comment">6 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-il-regno-di-ghiaccio-2013-italian-md-dual-1080p-brrip-x264-trtd-team-t8830076.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Il%20Regno%20Di%20Ghiaccio%202013%20iTALiAN%20MD%20DUAL%201080p%20BrRiP%20x264-TrTd_TeaM', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:29F3BAA8E9D417C5C181EC74E793A8F1E36534D8&dn=frozen+il+regno+di+ghiaccio+2013+italian+md+dual+1080p+brrip+x264+trtd+team&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:29F3BAA8E9D417C5C181EC74E793A8F1E36534D8&dn=frozen+il+regno+di+ghiaccio+2013+italian+md+dual+1080p+brrip+x264+trtd+team&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/29F3BAA8E9D417C5C181EC74E793A8F1E36534D8.torrent?title=[kat.cr]frozen.il.regno.di.ghiaccio.2013.italian.md.dual.1080p.brrip.x264.trtd.team" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-md-dual-1080p-brrip-x264-trtd-team-t8830076.html" class="torType filmType"></a>
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-md-dual-1080p-brrip-x264-trtd-team-t8830076.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-md-dual-1080p-brrip-x264-trtd-team-t8830076.html" class="cellMainLink"><strong class="red">Frozen</strong> Il Regno Di Ghiaccio <strong class="red">2013</strong> iTALiAN MD DUAL 1080p BrRiP x264-TrTd_TeaM</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ignazio71/">ignazio71</a> in <span id="cat_8830076"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.73 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="02 Mar 2014, 15:48">1&nbsp;year</td>
			<td class="green center">41</td>
			<td class="red lasttd center">5</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138908307">
            <td>
            <div class="iaconbox center floatright">
                				<a class="icon16" href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t8908307.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%5BBluRay%20Rip%5D%5BAC3%205.1%20Espa%C3%B1ol%20Castellano%5D%5B2013%5D', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:839481756BAC804CC8D345917037AF1584689106&dn=frozen+bluray+rip+ac3+5+1+espa%C3%B1ol+castellano+2013&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:839481756BAC804CC8D345917037AF1584689106&dn=frozen+bluray+rip+ac3+5+1+espa%C3%B1ol+castellano+2013&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/839481756BAC804CC8D345917037AF1584689106.torrent?title=[kat.cr]frozen.bluray.rip.ac3.5.1.espa%C3%B1ol.castellano.2013" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t8908307.html" class="torType filmType"></a>
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t8908307.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-bluray-rip-ac3-5-1-español-castellano-2013-t8908307.html" class="cellMainLink"><strong class="red">Frozen</strong> [BluRay Rip][AC3 5.1 Español Castellano][<strong class="red">2013</strong>]</a>

                                                <span class="font11px lightgrey block">
                in <span id="cat_8908307"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.86 <span>GB</span></td>
			<td class="center">1</td>
			<td class="center" title="22 Mar 2014, 16:48">1&nbsp;year</td>
			<td class="green center">42</td>
			<td class="red lasttd center">1</td>
			</tr>
						<tr class="even" id="torrent_frozen_201310726648">
            <td>
            <div class="iaconbox center floatright">
                <a rel="10726648,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html#comment">4 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20720p%20BRRip%20900MB%20-%20MkvCage', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:9D51B42EB769D409F26269BA01CE58E0DD14A7BC&dn=frozen+2013+720p+brrip+900mb+mkvcage&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:9D51B42EB769D409F26269BA01CE58E0DD14A7BC&dn=frozen+2013+720p+brrip+900mb+mkvcage&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/9D51B42EB769D409F26269BA01CE58E0DD14A7BC.torrent?title=[kat.cr]frozen.2013.720p.brrip.900mb.mkvcage" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="torType filmType"></a>
                <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) 720p BRRip 900MB - MkvCage</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/MkvCage/">MkvCage</a> in <span id="cat_10726648"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">899.49 <span>MB</span></td>
			<td class="center">1</td>
			<td class="center" title="31 May 2015, 19:59">8&nbsp;months</td>
			<td class="green center">38</td>
			<td class="red lasttd center">3</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138255709">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8255709,0" class="icommentjs kaButton smallButton rightButton" href="/va-frozen-2013-ost-itunes-deluxe-version-the-hh-t8255709.html#comment">47 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/va-frozen-2013-ost-itunes-deluxe-version-the-hh-t8255709.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'VA%20-%20Frozen%202013%20%28OST%29%20%28iTunes-Deluxe%20Version%29%20-%20the.HH', 'extension': 'm4a', 'magnet': 'magnet:?xt=urn:btih:6CADAF431D7B0EC967C3E656C5FDF9F2F803627B&dn=va+frozen+2013+ost+itunes+deluxe+version+the+hh&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:6CADAF431D7B0EC967C3E656C5FDF9F2F803627B&dn=va+frozen+2013+ost+itunes+deluxe+version+the+hh&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/6CADAF431D7B0EC967C3E656C5FDF9F2F803627B.torrent?title=[kat.cr]va.frozen.2013.ost.itunes.deluxe.version.the.hh" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/va-frozen-2013-ost-itunes-deluxe-version-the-hh-t8255709.html" class="torType musicType"></a>
                <a href="/va-frozen-2013-ost-itunes-deluxe-version-the-hh-t8255709.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType musicType">
                <a href="/va-frozen-2013-ost-itunes-deluxe-version-the-hh-t8255709.html" class="cellMainLink">VA - <strong class="red">Frozen</strong> <strong class="red">2013</strong> (OST) (iTunes-Deluxe Version) - the.HH</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Hulk/">Hulk</a> in <span id="cat_8255709"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">261.05 <span>MB</span></td>
			<td class="center">119</td>
			<td class="center" title="27 Nov 2013, 18:10">2&nbsp;years</td>
			<td class="green center">39</td>
			<td class="red lasttd center">0</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138351831">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8351831,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html#comment">662 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20TS%20x264%20AC3-MiLLENiUM', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:F165B9F028B092B2F44E128EB570DB994B0FB6AA&dn=frozen+2013+ts+x264+ac3+millenium&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:F165B9F028B092B2F44E128EB570DB994B0FB6AA&dn=frozen+2013+ts+x264+ac3+millenium&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/F165B9F028B092B2F44E128EB570DB994B0FB6AA.torrent?title=[kat.cr]frozen.2013.ts.x264.ac3.millenium" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="torType filmType"></a>
                <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="cellMainLink"><strong class="red">Frozen</strong> <strong class="red">2013</strong> TS x264 AC3-MiLLENiUM</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Acesn8s/">Acesn8s</a> in <span id="cat_8351831"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">873.14 <span>MB</span></td>
			<td class="center">5</td>
			<td class="center" title="12 Dec 2013, 04:14">2&nbsp;years</td>
			<td class="green center">33</td>
			<td class="red lasttd center">8</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138827685">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8827685,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-fullhd-1080p-brrip-x264-eng-latino-pitu-t8827685.html#comment">20 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-fullhd-1080p-brrip-x264-eng-latino-pitu-t8827685.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20FullHD%201080p%20BrRip%20x264%20Eng%20-%20Latino%20-%20Pitu', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:5A24FAB5126FD893E9E517E62A495FCBBD14873B&dn=frozen+2013+fullhd+1080p+brrip+x264+eng+latino+pitu&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:5A24FAB5126FD893E9E517E62A495FCBBD14873B&dn=frozen+2013+fullhd+1080p+brrip+x264+eng+latino+pitu&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/5A24FAB5126FD893E9E517E62A495FCBBD14873B.torrent?title=[kat.cr]frozen.2013.fullhd.1080p.brrip.x264.eng.latino.pitu" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-fullhd-1080p-brrip-x264-eng-latino-pitu-t8827685.html" class="torType filmType"></a>
                <a href="/frozen-2013-fullhd-1080p-brrip-x264-eng-latino-pitu-t8827685.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-fullhd-1080p-brrip-x264-eng-latino-pitu-t8827685.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) FullHD 1080p BrRip x264 Eng - Latino - Pitu</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/pitufo180/">pitufo180</a> in <span id="cat_8827685"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">2.48 <span>GB</span></td>
			<td class="center">5</td>
			<td class="center" title="01 Mar 2014, 23:31">1&nbsp;year</td>
			<td class="green center">34</td>
			<td class="red lasttd center">4</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138525060">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8525060,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html#comment">20 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20DVDScr%20NL%20subs%20DutchReleaseTeam', 'extension': 'avi', 'magnet': 'magnet:?xt=urn:btih:43D1B1B91D8BC4911EF62440E1E813265BC2AEE2&dn=frozen+2013+dvdscr+nl+subs+dutchreleaseteam&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:43D1B1B91D8BC4911EF62440E1E813265BC2AEE2&dn=frozen+2013+dvdscr+nl+subs+dutchreleaseteam&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/43D1B1B91D8BC4911EF62440E1E813265BC2AEE2.torrent?title=[kat.cr]frozen.2013.dvdscr.nl.subs.dutchreleaseteam" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="torType filmType"></a>
                <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) DVDScr NL subs DutchReleaseTeam</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Koedje/">Koedje</a> in <span id="cat_8525060"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">887.4 <span>MB</span></td>
			<td class="center">9</td>
			<td class="center" title="08 Jan 2014, 22:10">2&nbsp;years</td>
			<td class="green center">31</td>
			<td class="red lasttd center">9</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138780261">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8780261,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-soundtrack-deluxe-2013-aac-262-kbps-t8780261.html#comment">4 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-soundtrack-deluxe-2013-aac-262-kbps-t8780261.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Soundtrack%20%5BDeluxe%5D%20%282013%29%20AAC%2C%20~262%20kbps', 'extension': 'm4a', 'magnet': 'magnet:?xt=urn:btih:11C9F667FECAF06BEC0069541956189EE353092D&dn=frozen+soundtrack+deluxe+2013+aac+262+kbps&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:11C9F667FECAF06BEC0069541956189EE353092D&dn=frozen+soundtrack+deluxe+2013+aac+262+kbps&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/11C9F667FECAF06BEC0069541956189EE353092D.torrent?title=[kat.cr]frozen.soundtrack.deluxe.2013.aac.262.kbps" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-soundtrack-deluxe-2013-aac-262-kbps-t8780261.html" class="torType musicType"></a>
                <a href="/frozen-soundtrack-deluxe-2013-aac-262-kbps-t8780261.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType musicType">
                <a href="/frozen-soundtrack-deluxe-2013-aac-262-kbps-t8780261.html" class="cellMainLink"><strong class="red">Frozen</strong> Soundtrack [Deluxe] (<strong class="red">2013</strong>) AAC, ~262 kbps</a>

                                                <span class="font11px lightgrey block">
                in <span id="cat_8780261"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">261.27 <span>MB</span></td>
			<td class="center">60</td>
			<td class="center" title="17 Feb 2014, 00:54">1&nbsp;year</td>
			<td class="green center">29</td>
			<td class="red lasttd center">4</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138246547">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8246547,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-ost-mp3-t8246547.html#comment">33 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-ost-mp3-t8246547.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20%5BOST%5D%20%5BMP3%5D', 'extension': 'mp3', 'magnet': 'magnet:?xt=urn:btih:D3260CEE26BC1535163E2FF09A75F345645A465D&dn=frozen+2013+ost+mp3&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:D3260CEE26BC1535163E2FF09A75F345645A465D&dn=frozen+2013+ost+mp3&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/D3260CEE26BC1535163E2FF09A75F345645A465D.torrent?title=[kat.cr]frozen.2013.ost.mp3" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-ost-mp3-t8246547.html" class="torType musicType"></a>
                <a href="/frozen-2013-ost-mp3-t8246547.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType musicType">
                <a href="/frozen-2013-ost-mp3-t8246547.html" class="cellMainLink"><strong class="red">Frozen</strong> <strong class="red">2013</strong> [OST] [MP3]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/hopil/">hopil</a> in <span id="cat_8246547"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">311.54 <span>MB</span></td>
			<td class="center">60</td>
			<td class="center" title="26 Nov 2013, 11:20">2&nbsp;years</td>
			<td class="green center">28</td>
			<td class="red lasttd center">3</td>
			</tr>
						<tr class="odd" id="torrent_frozen_20138925943">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8925943,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-1080p-bluray-ac-3-x264-greek-tomcat12-etrg-t8925943.html#comment">35 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-1080p-bluray-ac-3-x264-greek-tomcat12-etrg-t8925943.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%5B2013%5D%201080p%20BluRay%20AC-3%20x264%5BGreek%5D-tomcat12%5BETRG%5D', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:A024DCFAA9903BA537EDC1E06F11DC2D1044D52D&dn=frozen+2013+1080p+bluray+ac+3+x264+greek+tomcat12+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A024DCFAA9903BA537EDC1E06F11DC2D1044D52D&dn=frozen+2013+1080p+bluray+ac+3+x264+greek+tomcat12+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/A024DCFAA9903BA537EDC1E06F11DC2D1044D52D.torrent?title=[kat.cr]frozen.2013.1080p.bluray.ac.3.x264.greek.tomcat12.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-1080p-bluray-ac-3-x264-greek-tomcat12-etrg-t8925943.html" class="torType filmType"></a>
                <a href="/frozen-2013-1080p-bluray-ac-3-x264-greek-tomcat12-etrg-t8925943.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-1080p-bluray-ac-3-x264-greek-tomcat12-etrg-t8925943.html" class="cellMainLink"><strong class="red">Frozen</strong> [<strong class="red">2013</strong>] 1080p BluRay AC-3 x264[Greek]-tomcat12[ETRG]</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/tomcat-12/">tomcat-12</a> in <span id="cat_8925943"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">3.06 <span>GB</span></td>
			<td class="center">4</td>
			<td class="center" title="27 Mar 2014, 02:03">1&nbsp;year</td>
			<td class="green center">26</td>
			<td class="red lasttd center">7</td>
			</tr>
						<tr class="even" id="torrent_frozen_20138320897">
            <td>
            <div class="iaconbox center floatright">
                <a rel="8320897,0" class="icommentjs kaButton smallButton rightButton" href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html#comment">23 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'VA%20-%20Frozen%20%5BSoundtrack%5D%20-%202013%20%28MP3%29%20-%20C4%20%7BGTRG%7D', 'extension': 'mp3', 'magnet': 'magnet:?xt=urn:btih:A6892632EA49265007B47747B5833568B66F07FB&dn=va+frozen+soundtrack+2013+mp3+c4+gtrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A6892632EA49265007B47747B5833568B66F07FB&dn=va+frozen+soundtrack+2013+mp3+c4+gtrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/A6892632EA49265007B47747B5833568B66F07FB.torrent?title=[kat.cr]va.frozen.soundtrack.2013.mp3.c4.gtrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="torType musicType"></a>
                <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType musicType">
                <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="cellMainLink">VA - <strong class="red">Frozen</strong> [Soundtrack] - <strong class="red">2013</strong> (MP3) - C4 {GTRG}</a>

                                                <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Kashi2052/">Kashi2052</a> in <span id="cat_8320897"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">115.61 <span>MB</span></td>
			<td class="center">39</td>
			<td class="center" title="07 Dec 2013, 09:18">2&nbsp;years</td>
			<td class="green center">27</td>
			<td class="red lasttd center">4</td>
			</tr>
						<tr class="odd" id="torrent_frozen_201311754555">
            <td>
            <div class="iaconbox center floatright">
                <a rel="11754555,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-bluray-x264-dual-audio-hindi-2-0-english-dd-5-1-loki-m2tv-t11754555.html#comment">9 <i class="ka ka-comment"></i></a>				<a class="icon16" href="/frozen-2013-720p-bluray-x264-dual-audio-hindi-2-0-english-dd-5-1-loki-m2tv-t11754555.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a>                                <div data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20720p%20BluRay%20x264%20%5BDual%20Audio%5D%20%5BHindi%202.0%20-%20English%20DD%205.1%20%5D%20-%20LOKI%20-%20M2Tv', 'extension': 'mkv', 'magnet': 'magnet:?xt=urn:btih:579757C3A6B53652BEF7560D2E98292979CA9B24&dn=frozen+2013+720p+bluray+x264+dual+audio+hindi+2+0+english+dd+5+1+loki+m2tv&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce' }"></div>
                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:579757C3A6B53652BEF7560D2E98292979CA9B24&dn=frozen+2013+720p+bluray+x264+dual+audio+hindi+2+0+english+dd+5+1+loki+m2tv&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                <a data-download title="Download torrent file" href="//torcache.net/torrent/579757C3A6B53652BEF7560D2E98292979CA9B24.torrent?title=[kat.cr]frozen.2013.720p.bluray.x264.dual.audio.hindi.2.0.english.dd.5.1.loki.m2tv" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
            </div>
            <div class="torrentname">
                <a href="/frozen-2013-720p-bluray-x264-dual-audio-hindi-2-0-english-dd-5-1-loki-m2tv-t11754555.html" class="torType filmType"></a>
                <a href="/frozen-2013-720p-bluray-x264-dual-audio-hindi-2-0-english-dd-5-1-loki-m2tv-t11754555.html" class="normalgrey font12px plain bold"></a>
            <div class="markeredBlock torType filmType">
                <a href="/frozen-2013-720p-bluray-x264-dual-audio-hindi-2-0-english-dd-5-1-loki-m2tv-t11754555.html" class="cellMainLink"><strong class="red">Frozen</strong> (<strong class="red">2013</strong>) 720p BluRay x264 [Dual Audio] [Hindi 2.0 - English DD 5.1 ] - LOKI - M2Tv</a>

                                                <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/LOKI-Torrents/">LOKI-Torrents</a> in <span id="cat_11754555"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span>                	                </span>
            	            </div>
            </td>
									<td class="nobr center">1.06 <span>GB</span></td>
			<td class="center">5</td>
			<td class="center" title="14 Dec 2015, 13:37">1&nbsp;month</td>
			<td class="green center">22</td>
			<td class="red lasttd center">12</td>
			</tr>
			</table>
	<div class="pages botmarg5px floatright" baseurl="/usearch/frozen%202013/">
<a class="turnoverButton siteButton bigButton kaTurnoverButton pagespecify_js" title="Go to a specific page"><i class="ka ka-zoom"></i></a><a class="turnoverButton siteButton bigButton active">1</a><a rel="nofollow" href="/usearch/frozen%202013/2/" class="turnoverButton siteButton bigButton">2</a><a rel="nofollow" href="/usearch/frozen%202013/3/" class="turnoverButton siteButton bigButton">3</a><a rel="nofollow" href="/usearch/frozen%202013/4/" class="turnoverButton siteButton bigButton">4</a><a rel="nofollow" href="/usearch/frozen%202013/5/" class="turnoverButton siteButton bigButton">5</a><a class="turnoverButton siteButton blank nohov"></a><a rel="nofollow" href="/usearch/frozen%202013/17/" class="turnoverButton siteButton bigButton">17</a>	<script type="text/javascript">
		$(function() {
			if ($('.pages .nohov').length==0)
				$('.pages .kaTurnoverButton').hide();
		});
		$('.pagespecify_js').unbind('click').on('click', function() {
			var pageNum = prompt('Enter page number');
			if (!isNaN(pageNum) && parseInt(pageNum)>0) {
				var url = $(this).parent().attr('baseurl'); var last = $(this).parent().find('a[href]').last();
				var paramStyle = /\/\?page=/.test(last.attr('href')) ? 2 : (/\/\?.*\&page=/.test(last.attr('href')) ? 1 : 0);
				var url_to = paramStyle==0||paramStyle==2 ? (url.substring(0, url.lastIndexOf('/'))+'/'+(paramStyle==2?'?page='+pageNum+url.substring(url.lastIndexOf('/')+1).replace(/^\?([^\=]+=)/, '&$1'):pageNum+url.substring(url.lastIndexOf('/')))) : url+'&page='+pageNum;
				console.log(url_to);
				if (last.is('.ajaxLink')) { // if last button is .ajaxLink then it implies it's being fancyboxed, or at least the destination page(s) should be fancyboxed.
					$('<a href="'+url_to+'"'+(last.is('[rel="nofollow"]')?' rel="nofollow"':'')+'></a>').fancybox().click();
				}else{
					location.href = url_to;
				}
			}
		});
	</script>
</div>
</div>
		<div class="lightgrey">
			Search for "frozen 2013" on <a href="http://torrentz.eu/search?f=frozen 2013">Torrentz.eu</a>
		</div>
		</td>
		<td class="sidebarCell">

<div id="sidebar" >


        <div  data-sc-slot="_119b0a17fab5493361a252d04bf527db"></div>


    	    <div class="spareBlock">
    <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
    <div  data-sc-slot="_7063408f1c01d50e0dc2d833186ce962" data-sc-params="{ 'searchQuery': 'frozen 2013' }"></div>
</div>


        <div class="sliderbox">
<h3><a href="/community/">Latest Forum Threads</a><i id="hideLatestThreads" class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestForum" rel="latestForum" class="showBlockJS">
		<li>
		<a href="/community/show/can-t-recall-title-ask-here/?unread=17387324">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Can&#039;t recall the title? Ask here!
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_1"><a class="plain" href="/user/boss_man/">boss_man</a></span></span> <time class="timeago" datetime="2016-02-06T20:04:58+00:00">06 Feb 2016, 20:04</time></span>
	</li>
		<li>
		<a href="/community/show/saddest-movie-you-ever-watched/?unread=17387322">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Saddest movie you ever watched?
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/Brownpoint/">Brownpoint</a></span></span> <time class="timeago" datetime="2016-02-06T20:04:07+00:00">06 Feb 2016, 20:04</time></span>
	</li>
		<li>
		<a href="/community/show/what-tv-show-are-you-watching-right-now-v4-thread-120579/?unread=17387319">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				What TV show are you watching right now? V4
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/mooseman6/">mooseman6</a></span></span> <time class="timeago" datetime="2016-02-06T20:02:57+00:00">06 Feb 2016, 20:02</time></span>
	</li>
		<li>
		<a href="/community/show/your-main-reason-pirating/?unread=17387318">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Your main reason for pirating?
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_1"><a class="plain" href="/user/PeasantMagic/">PeasantMagic</a></span></span> <time class="timeago" datetime="2016-02-06T20:02:41+00:00">06 Feb 2016, 20:02</time></span>
	</li>
		<li>
		<a href="/community/show/does-anyone-have-any-recent-sci-fi-fantasy-i-haven-t-seen/?unread=17387314">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Does Anyone have any recent sci-fi/fantasy that I haven&#039;t seen?
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/katja1976/">katja1976</a></span></span> <time class="timeago" datetime="2016-02-06T20:00:23+00:00">06 Feb 2016, 20:00</time></span>
	</li>
		<li>
		<a href="/community/show/gotta-tech-problem-post-it-here/?unread=17387311">
			<i class="ka ka16 ka-community latest-icon"></i>
			<p class="latest-title">
				Gotta tech problem? Post it here
			</p>
		</a>
		<span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_2"><a class="plain" href="/user/ScribeOfGoD/">ScribeOfGoD</a></span></span> <time class="timeago" datetime="2016-02-06T19:57:26+00:00">06 Feb 2016, 19:57</time></span>
	</li>
	</ul>
</div><!-- div class="sliderbox" -->

    <div class="sliderbox">
<h3><a href="/blog/">Latest News</a><i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestNews" rel="latestNews" class="showBlockJS">
	<li>
		<a href="/blog/post/merry-xmas/">
			<i class="ka ka16 ka-rss latest-icon"></i>
			<p class="latest-title">
				Merry Xmas
			</p>
		</a>
		<span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-12-23T16:54:28+00:00">23 Dec 2015, 16:54</time></span>
	</li>
	<li>
		<a href="/blog/post/new-site-rules/">
			<i class="ka ka16 ka-rss latest-icon"></i>
			<p class="latest-title">
				New site Rules
			</p>
		</a>
		<span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-10-15T14:18:43+00:00">15 Oct 2015, 14:18</time></span>
	</li>
	<li>
		<a href="/blog/post/look-mama-i-m-popular/">
			<i class="ka ka16 ka-rss latest-icon"></i>
			<p class="latest-title">
				Look, mama, I&#039;m popular!
			</p>
		</a>
		<span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-10-05T17:42:40+00:00">05 Oct 2015, 17:42</time></span>
	</li>
</ul>
</div><!-- div class="sliderbox" -->
<div class="sliderbox">
<h3>Blogroll<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="blogroll" rel="blogroll" class="showBlockJS">
	<li><a href="/blog/spottingeye/post/brrr-what-a-day/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Brrr! What a day!</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/spottingeye/">spottingeye</a> <time class="timeago" datetime="2016-02-05T12:14:23+00:00">05 Feb 2016, 12:14</time></span></li>
	<li><a href="/blog/Siddharth.S/post/ilayathalapathy-vijay-theri-stylish-cop/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Ilayathalapathy Vijay - Theri - Stylish Cop</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/Siddharth.S/">Siddharth.S</a> <time class="timeago" datetime="2016-02-05T08:08:19+00:00">05 Feb 2016, 08:08</time></span></li>
	<li><a href="/blog/XGrimReaperX/post/greed/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Greed</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/XGrimReaperX/">XGrimReaperX</a> <time class="timeago" datetime="2016-02-04T09:06:35+00:00">04 Feb 2016, 09:06</time></span></li>
	<li><a href="/blog/BBCLover./post/katian-s-log-part-3-by-entropy169/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> KATian&#039;s Log - Part 3 by Entropy169</p></a><span class="explanation">by <a class="plain aclColor_4" href="/user/BBCLover./">BBCLover.</a> <time class="timeago" datetime="2016-02-03T13:14:23+00:00">03 Feb 2016, 13:14</time></span></li>
	<li><a href="/blog/olderthangod/post/stagger-lee/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Stagger Lee</p></a><span class="explanation">by <a class="plain aclColor_2" href="/user/olderthangod/">olderthangod</a> <time class="timeago" datetime="2016-02-02T17:51:46+00:00">02 Feb 2016, 17:51</time></span></li>
	<li><a href="/blog/Exterminator/post/my-ideas/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> My ideas!</p></a><span class="explanation">by <a class="plain aclColor_2" href="/user/Exterminator/">Exterminator</a> <time class="timeago" datetime="2016-02-02T14:28:16+00:00">02 Feb 2016, 14:28</time></span></li>
</ul>
</div><!-- div class="sliderbox" -->

    <div class="sliderbox">
<h3>Goodies<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="goodies" rel="goodies" class="showBlockJS">

	<li>
		<a data-nop target="_blank" rel="external" href="http://addons.mozilla.org/en-US/firefox/addon/11412" target="_blank" rel="external">
			<span class="ifirefox thirdPartIcons"></span>Firefox search plugin
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="/content/utorrent.btsearch">
			<span class="iutorrent thirdPartIcons"></span>uTorrent search template
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="http://twitter.com/kickasstorrents">
			<span class="ifollow thirdPartIcons"></span>Follow us on Twitter
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="/blog/post/30/">
			<span class="ikat thirdPartIcons"></span>Kickass wallpapers
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external" href="http://www.facebook.com/official.KAT.fanclub">
			<span class="ifacebook thirdPartIcons"></span>Like us on Facebook
		</a>
	</li>
	<li>
		<a data-nop target="_blank" rel="external nofollow" href="http://chat.efnet.org:9090/?channels=%23KAT.ph"><span class="iirc thirdPartIcons"></span>IRC official chat</a>
	</li>
</ul>
</div><!-- div class="sliderbox" -->
    <div class="sliderbox">
<h3>Latest Searches<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
<ul id="latestSearches" rel="latestSearches" class="showBlockJS">
	<li>
		<a href="/search/the%20locket%201946/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				the locket 1946
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/virtualrealporn/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				virtualrealporn
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/solace%202015/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				Solace 2015
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/red%20tails%20%282012%29/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				Red Tails (2012)
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/xxx/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				xxx
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/frozen%202013/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				frozen 2013
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/dream%20cars/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				dream cars
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/children/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				children
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/mom.xxx/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				mom.xxx
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/shaun%20the%20sheep/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				Shaun the Sheep
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

	<li>
		<a href="/search/windows%208%20pt/">
			<i class="ka ka16 ka-zoom latest-icon"></i>
			<p class="latest-title">
				windows 8 pt
			</p>
		</a>
				<span class="explanation">just&nbsp;now</span>
	</li>

</ul>
</div><!-- div class="sliderbox" -->
        	<div class="sliderbox">
	<h3>Friends Links<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
    <ul id="friendsLinks" rel="friendsLinks" class="showBlockJS">

		<li>
			<a data-nop href="http://torrents.to/" target="_blank" rel="external">
				<span class="itorrentsto thirdPartIcons"></span>Torrents.to
			</a>
		</li>
		<li>
			<a data-nop href="http://www.torrentdownloads.net/" target="_blank" rel="external">
				<span class="itorrentdownloads thirdPartIcons"></span>Torrent Downloads
			</a>
		</li>




		<li>
			<a data-nop href="http://torrent-finder.info/" target="_blank" rel="external">
				<span class="itorrentfinder thirdPartIcons"></span>Torrent Finder
			</a>
		</li>
	</ul>
</div><!-- div class="sliderbox" -->

</div>
<a class="showSidebar" id="showsidebar" onclick="showSidebar();" style="display:none;"></a>

		</td>
	</tr>
</table>
<div class="rightcell">
</div><!-- div class="rightcell" -->
<div class="leftcell">
</div>
</div>
<div id="translate_site" style="display:none">
    <h3>Select Your Language</h3>
    <div class="textcontent">
        <div style="line-height:140%;-moz-column-width: 12em; -moz-columns: 12em; -webkit-columns: 12em; columns:12em;">
            <ul>
                                <li class="current_lang"><a href="#" onclick="setLanguage('en', '.kat.cr');return false;" class="plain"><strong>English</strong></a></li>
                                <li><a href="#" onclick="setLanguage('af', '.kat.cr');return false;" class="plain">Afrikaans</a></li>
                                <li><a href="#" onclick="setLanguage('al', '.kat.cr');return false;" class="plain">Albanian</a></li>
                                <li><a href="#" onclick="setLanguage('ar', '.kat.cr');return false;" class="plain">Arabic (Modern)</a></li>
                                <li><a href="#" onclick="setLanguage('eu', '.kat.cr');return false;" class="plain">Basque</a></li>
                                <li><a href="#" onclick="setLanguage('bn', '.kat.cr');return false;" class="plain">Bengali</a></li>
                                <li><a href="#" onclick="setLanguage('bs', '.kat.cr');return false;" class="plain">Bosnian</a></li>
                                <li><a href="#" onclick="setLanguage('br', '.kat.cr');return false;" class="plain">Brazilian Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('bg', '.kat.cr');return false;" class="plain">Bulgarian</a></li>
                                <li><a href="#" onclick="setLanguage('ch', '.kat.cr');return false;" class="plain">Chinese Simplified</a></li>
                                <li><a href="#" onclick="setLanguage('tw', '.kat.cr');return false;" class="plain">Chinese Traditional</a></li>
                                <li><a href="#" onclick="setLanguage('hr', '.kat.cr');return false;" class="plain">Croatian</a></li>
                                <li><a href="#" onclick="setLanguage('cz', '.kat.cr');return false;" class="plain">Czech</a></li>
                                <li><a href="#" onclick="setLanguage('da', '.kat.cr');return false;" class="plain">Danish</a></li>
                                <li><a href="#" onclick="setLanguage('nl', '.kat.cr');return false;" class="plain">Dutch</a></li>
                                <li><a href="#" onclick="setLanguage('tl', '.kat.cr');return false;" class="plain">Filipino</a></li>
                                <li><a href="#" onclick="setLanguage('fi', '.kat.cr');return false;" class="plain">Finnish</a></li>
                                <li><a href="#" onclick="setLanguage('fr', '.kat.cr');return false;" class="plain">French</a></li>
                                <li><a href="#" onclick="setLanguage('ka', '.kat.cr');return false;" class="plain">Georgian</a></li>
                                <li><a href="#" onclick="setLanguage('de', '.kat.cr');return false;" class="plain">German</a></li>
                                <li><a href="#" onclick="setLanguage('el', '.kat.cr');return false;" class="plain">Greek</a></li>
                                <li><a href="#" onclick="setLanguage('he', '.kat.cr');return false;" class="plain">Hebrew</a></li>
                                <li><a href="#" onclick="setLanguage('hi', '.kat.cr');return false;" class="plain">Hindi</a></li>
                                <li><a href="#" onclick="setLanguage('hu', '.kat.cr');return false;" class="plain">Hungarian</a></li>
                                <li><a href="#" onclick="setLanguage('id', '.kat.cr');return false;" class="plain">Indonesian</a></li>
                                <li><a href="#" onclick="setLanguage('it', '.kat.cr');return false;" class="plain">Italian</a></li>
                                <li><a href="#" onclick="setLanguage('kn', '.kat.cr');return false;" class="plain">Kannada</a></li>
                                <li><a href="#" onclick="setLanguage('ko', '.kat.cr');return false;" class="plain">Korean</a></li>
                                <li><a href="#" onclick="setLanguage('lv', '.kat.cr');return false;" class="plain">Latvian</a></li>
                                <li><a href="#" onclick="setLanguage('lt', '.kat.cr');return false;" class="plain">Lithuanian</a></li>
                                <li><a href="#" onclick="setLanguage('mk', '.kat.cr');return false;" class="plain">Macedonian</a></li>
                                <li><a href="#" onclick="setLanguage('ml', '.kat.cr');return false;" class="plain">Malayalam</a></li>
                                <li><a href="#" onclick="setLanguage('ms', '.kat.cr');return false;" class="plain">Malaysian</a></li>
                                <li><a href="#" onclick="setLanguage('ne', '.kat.cr');return false;" class="plain">Nepali</a></li>
                                <li><a href="#" onclick="setLanguage('no', '.kat.cr');return false;" class="plain">Norwegian</a></li>
                                <li><a href="#" onclick="setLanguage('pr', '.kat.cr');return false;" class="plain">Pirate</a></li>
                                <li><a href="#" onclick="setLanguage('pl', '.kat.cr');return false;" class="plain">Polish</a></li>
                                <li><a href="#" onclick="setLanguage('pt', '.kat.cr');return false;" class="plain">Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('pa', '.kat.cr');return false;" class="plain">Punjabi</a></li>
                                <li><a href="#" onclick="setLanguage('ro', '.kat.cr');return false;" class="plain">Romanian</a></li>
                                <li><a href="#" onclick="setLanguage('ru', '.kat.cr');return false;" class="plain">Russian</a></li>
                                <li><a href="#" onclick="setLanguage('sr', '.kat.cr');return false;" class="plain">Serbian</a></li>
                                <li><a href="#" onclick="setLanguage('src', '.kat.cr');return false;" class="plain">Serbian-Cyrillic</a></li>
                                <li><a href="#" onclick="setLanguage('bsc', '.kat.cr');return false;" class="plain">Serbian-Cyrillic (ijekavica)</a></li>
                                <li><a href="#" onclick="setLanguage('si', '.kat.cr');return false;" class="plain">Sinhala</a></li>
                                <li><a href="#" onclick="setLanguage('sk', '.kat.cr');return false;" class="plain">Slovak</a></li>
                                <li><a href="#" onclick="setLanguage('sl', '.kat.cr');return false;" class="plain">Slovenian</a></li>
                                <li><a href="#" onclick="setLanguage('es', '.kat.cr');return false;" class="plain">Spanish</a></li>
                                <li><a href="#" onclick="setLanguage('sv', '.kat.cr');return false;" class="plain">Swedish</a></li>
                                <li><a href="#" onclick="setLanguage('ta', '.kat.cr');return false;" class="plain">Tamil</a></li>
                                <li><a href="#" onclick="setLanguage('te', '.kat.cr');return false;" class="plain">Telugu</a></li>
                                <li><a href="#" onclick="setLanguage('tr', '.kat.cr');return false;" class="plain">Turkish</a></li>
                                <li><a href="#" onclick="setLanguage('uk', '.kat.cr');return false;" class="plain">Ukrainian</a></li>
                                <li><a href="#" onclick="setLanguage('ur', '.kat.cr');return false;" class="plain">Urdu</a></li>
                                <li><a href="#" onclick="setLanguage('vi', '.kat.cr');return false;" class="plain">Vietnamese</a></li>
                            </ul>
        </div>
    </div><!-- div class="textcontent" -->
</div>
</div><!--id="main"-->
</div><!--id="wrap"-->

<footer class="lightgrey">
	<ul>
		<li><a class="plain" data-nop href="#translate_site" id="translate_link"><strong>change language</strong></a></li>
		<li><a href="/rules/" class="lower">rules</a></li>
        <li><a href="/ideabox/">idea box</a></li>
		<li class="lower"><a href="/achievements/">Achievements</a></li>
		<li><a href="/trends/">trends</a></li>
		<li class="lower"><a href="/latest-searches/">Latest Searches</a></li>
        <li><a href="/request/">torrent requests</a></li>        	</ul>
	<ul>
		<li><a href="/about/">about</a></li>
        		<li><a href="/privacy/">privacy</a></li>
		<li><a href="/dmca/">dmca</a></li>
        		<li><a href="/logos/">logos</a></li>
				<li><a href="/contacts/">contacts</a></li>
        <li><a href="/api/">api</a></li>
        <li><a href="https://kastatus.com">KAT status</a></li>
		<li><a target="_blank" rel="external nofollow" href="http://chat.efnet.org:9090/?channels=%23KAT.ph">chat</a></li>
	</ul>
        </footer>
<a class="feedbackButton eventsButtons" href="/issue/create/" id="feedback"><span>Report a bug</span></a>
    <div  data-sc-slot="_673e31f53f8166159b8e996c4124765b"></div>
        <div  data-sc-slot="_e7050fb15fd39b3e4e99a5be4a57b6ea"></div>
<script>
 sc('addGlobal', 'pagetype', 'other');
</script>
<script type="text/javascript"><!--
document.write("<a style='display:none;' href='http://www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t45.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";h"+escape(document.title.substring(0,80))+";"+Math.random()+
"' alt='' title='LiveInternet' "+
"border='0' width='0' height='0'><\/a>")
//--></script>

</body>
</html>

'''

from bs4 import BeautifulSoup

soup = BeautifulSoup(data, 'html5lib')
links = soup.table.tbody.find_all('tr', {'class': ['odd', 'even']})

for link in links:
    columns = link.select('td')
    print len(columns)
    print columns[0].find('a', class_='cellMainLink').text  # name
    print columns[0].find('a', {'title': 'Torrent magnet link'})['href']  # name
    # print columns[1]  # magnet
    print columns[1].text  # size
    print columns[4].text  # seeds
    print columns[5].text  # peers
    print "************************"
