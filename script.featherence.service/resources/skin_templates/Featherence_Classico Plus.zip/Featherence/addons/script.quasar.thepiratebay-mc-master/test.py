# coding: utf-8
__author__ = 'mancuniancol'

data = '''

<!DOCTYPE html>
<html lang="en">
<head>
<title>The Pirate Bay - The galaxy's most resilient bittorrent site</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="google-site-verification" content=""/>
<link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="Search The Pirate Bay"/>
<link rel="stylesheet" type="text/css" href="https://thepiratebay.rs/css/pirate6.css"/>
<link rel="dns-prefetch" href="//syndication.exoclick.com/">
<link rel="dns-prefetch" href="//main.exoclick.com/">
<link rel="dns-prefetch" href="//static-ssl.exoclick.com/">
<link rel="dns-prefetch" href="//ads.exoclick.com/">
<link rel="canonical" href="https://thepiratebay.rs/search/the-walking-dead-s06e08/0/99/200"/>
<style type="text/css">.searchBox{margin:6px;width:300px;vertical-align:middle;padding:2px;background-image:url('https://thepiratebay.rs/static/img/icon-http.gif');background-repeat:no-repeat;background-position:right;}.detLink{font-size:1.2em;font-weight:400;}.detDesc{color:#4e5456;}.detDesc a:hover{color:#000099;text-decoration:underline;}.sortby{text-align:left;float:left;}.detName{padding-top:3px;padding-bottom:2px;}.viewswitch{font-style:normal;float:right;text-align:right;font-weight:normal;}</style>
<meta name="description" content="Search for and download any torrent from the pirate bay using search query the walking dead s06e08. Direct download via magnet link."/>
<meta name="keywords" content="the walking dead s06e08 direct download torrent magnet tpb piratebay search"/>

<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 1003349]);
  _pop.push(['minBid', 0.000000]);
  _pop.push(['popundersPerIP', 0]);
  _pop.push(['delayBetween', 0]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 0]);
  _pop.push(['topmostLayer', false]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0];
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-71596015-1', 'auto');
  ga('send', 'pageview');

</script> </head>
<body>
<div id="header">
<form method="get" id="q" action="/search.php">
<a href="/" class="img"><img src="https://thepiratebay.rs/static/img/tpblogo_sm_ny.gif" id="TPBlogo" alt="The Pirate Bay"/></a>
<b><a href="/" title="Search Torrents">Search Torrents</a></b>&nbsp;&nbsp;|&nbsp;
<a href="/browse" title="Browse Torrents">Browse Torrents</a>&nbsp;&nbsp;|&nbsp;
<a href="/recent" title="Recent Torrent">Recent Torrents</a>&nbsp;&nbsp;|&nbsp;
<a href="/tv/" title="TV shows">TV shows</a>&nbsp;&nbsp;|&nbsp;
<a href="/music" title="Music">Music</a>&nbsp;&nbsp;|&nbsp;
<a href="/top" title="Top 100">Top 100</a>
<br/><input type="search" class="inputbox" title="Pirate Search" name="q" placeholder="Search here..." value="the walking dead s06e08"/><input value="Pirate Search" type="submit" class="submitbutton"/><br/> <label for="audio" title="Audio"><input id="audio" name="audio" onclick="javascript:rmAll();" type="checkbox"/>Audio</label>
<label for="video" title="Video"><input id="video" name="video" onclick="javascript:rmAll();" type="checkbox" checked="checked"/>Video</label>
<label for="apps" title="Applications"><input id="apps" name="apps" onclick="javascript:rmAll();" type="checkbox"/>Applications</label>
<label for="games" title="Games"><input id="games" name="games" onclick="javascript:rmAll();" type="checkbox"/>Games</label>
<label for="porn" title="Porn"><input id="porn" name="porn" onclick="javascript:rmAll();" type="checkbox"/>Porn</label>
<label for="other" title="Other"><input id="other" name="other" onclick="javascript:rmAll();" type="checkbox"/>Other</label>
<select id="category" name="category" onchange="javascript:setAll();">
<option value="0">All</option>
<optgroup label="Audio">
<option value="101">Music</option>
<option value="102">Audio books</option>
<option value="103">Sound clips</option>
<option value="104">FLAC</option>
<option value="199">Other</option>
</optgroup>
<optgroup label="Video">
<option value="201">Movies</option>
<option value="202">Movies DVDR</option>
<option value="203">Music videos</option>
<option value="204">Movie clips</option>
<option value="205">TV shows</option>
<option value="206">Handheld</option>
<option value="207">HD - Movies</option>
<option value="208">HD - TV shows</option>
<option value="209">3D</option>
<option value="299">Other</option>
</optgroup>
<optgroup label="Applications">
<option value="301">Windows</option>
<option value="302">Mac</option>
<option value="303">UNIX</option>
<option value="304">Handheld</option>
<option value="305">IOS (iPad/iPhone)</option>
<option value="306">Android</option>
<option value="399">Other OS</option>
</optgroup>
<optgroup label="Games">
<option value="401">PC</option>
<option value="402">Mac</option>
<option value="403">PSx</option>
<option value="404">XBOX360</option>
<option value="405">Wii</option>
<option value="406">Handheld</option>
<option value="407">IOS (iPad/iPhone)</option>
<option value="408">Android</option>
<option value="499">Other</option>
</optgroup>
<optgroup label="Porn">
<option value="501">Movies</option>
<option value="502">Movies DVDR</option>
<option value="503">Pictures</option>
<option value="504">Games</option>
<option value="505">HD - Movies</option>
<option value="506">Movie clips</option>
<option value="599">Other</option>
</optgroup>
<optgroup label="Other">
<option value="601">E-books</option>
<option value="602">Comics</option>
<option value="603">Pictures</option>
<option value="604">Covers</option>
<option value="605">Physibles</option>
<option value="699">Other</option>
</optgroup>
</select>
<input type="hidden" name="page" value="0"/>
<input type="hidden" name="orderby" value="99"/>
</form>
</div>
<h2><span>Search results: the walking dead s06e08</span>&nbsp;Displaying hits from 0 to 28 (approx 28 found)</h2>
<div id="SearchResults"><div id="content">
<div id="sky-right">
</div>
<div id="main-content">
<table id="searchResult">
<thead id="tableHead">
<tr class="header">
<th><a href="/search/the-walking-dead-s06e08/0/13/200" title="Order by Type">Type</a></th>
<th><div class="sortby"><a href="/search/the-walking-dead-s06e08/0/1/200" title="Order by Name">Name</a> (Order by: <a href="/search/the-walking-dead-s06e08/0/3/200" title="Order by Uploaded">Uploaded</a>, <a href="/search/the-walking-dead-s06e08/0/5/200" title="Order by Size">Size</a>, <span style="white-space: nowrap;"><a href="/search/the-walking-dead-s06e08/0/11/200" title="Order by ULed by">ULed by</a></span>, <a href="/search/the-walking-dead-s06e08/0/8/200" title="Order by Seeders">SE</a>, <a href="/search/the-walking-dead-s06e08/0/9/200" title="Order by Leechers">LE</a>)</div><div class="viewswitch"> View: <a href="#" onClick="alert('This feature is not yet supported. I need to spend a long time adding support for cookies, if/when I do this feature will work.')">Single</a> / Double&nbsp;</div></th>
<th><abbr title="Seeders"><a href="/search/the-walking-dead-s06e08/0/8/200" title="Order by Seeders">SE</a></abbr></th>
<th><abbr title="Leechers"><a href="/search/the-walking-dead-s06e08/0/9/200" title="Order by Leechers">LE</a></abbr></th>
</tr>
</thead>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869656/The.Walking.Dead.S06E08.HDTV.x264-KILLERS[ettv]" class="detLink" title="Details for The.Walking.Dead.S06E08.HDTV.x264-KILLERS[ettv]">The.Walking.Dead.S06E08.HDTV.x264-KILLERS[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:cdc6f775a1a8df39ee85decac4222691a8e8a8a3&dn=The.Walking.Dead.S06E08.HDTV.x264-KILLERS%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpjZGM2Zjc3NWExYThkZjM5ZWU4NWRlY2FjNDIyMjY5MWE4ZThhOGEzJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LkhEVFYueDI2NC1LSUxMRVJTJTVCZXR0diU1RCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The.Walking.Dead.S06E08.HDTV.x264-KILLERS[ettv]&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 19 comments." title="This torrent has 19 comments."/><a href="/user/ettv"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 395.76&nbsp;MiB, ULed by <a class="detDesc" href="/user/ettv/" title="Browse ettv">ettv</a></font>
</td>
<td align="right">721</td>
<td align="right">139</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12870951/The.Walking.Dead.S06E08.HDTV.x264-KILLERS" class="detLink" title="Details for The.Walking.Dead.S06E08.HDTV.x264-KILLERS">The.Walking.Dead.S06E08.HDTV.x264-KILLERS</a>
</div>
<a href="magnet:?xt=urn:btih:0ffb20e86ad12513830010f0ab7177fd2dc509a5&dn=The.Walking.Dead.S06E08.HDTV.x264-KILLERS&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDowZmZiMjBlODZhZDEyNTEzODMwMDEwZjBhYjcxNzdmZDJkYzUwOWE1JmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LkhEVFYueDI2NC1LSUxMRVJTJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.HDTV.x264-KILLERS&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/OvoJeKraj"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 395.77&nbsp;MiB, ULed by <a class="detDesc" href="/user/OvoJeKraj/" title="Browse OvoJeKraj">OvoJeKraj</a></font>
</td>
<td align="right">492</td>
<td align="right">6</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869761/The.Walking.Dead.S06E08.HDTV.XviD-FUM[ettv]" class="detLink" title="Details for The.Walking.Dead.S06E08.HDTV.XviD-FUM[ettv]">The.Walking.Dead.S06E08.HDTV.XviD-FUM[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:e066564a80bae1c62d718ee36394729da16358a6&dn=The.Walking.Dead.S06E08.HDTV.XviD-FUM%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDplMDY2NTY0YTgwYmFlMWM2MmQ3MThlZTM2Mzk0NzI5ZGExNjM1OGE2JmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LkhEVFYuWHZpRC1GVU0lNUJldHR2JTVEJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.HDTV.XviD-FUM[ettv]&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 8 comments." title="This torrent has 8 comments."/><a href="/user/ettv"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 347.16&nbsp;MiB, ULed by <a class="detDesc" href="/user/ettv/" title="Browse ettv">ettv</a></font>
</td>
<td align="right">140</td>
<td align="right">4</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869655/The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[ettv]" class="detLink" title="Details for The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[ettv]">The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:db955d0576113c3930de15b7340c0886eea8d55d&dn=The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkYjk1NWQwNTc2MTEzYzM5MzBkZTE1YjczNDBjMDg4NmVlYThkNTVkJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjcyMHAuSERUVi54MjY0LUtJTExFUlMlNUJldHR2JTVEJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[ettv]&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 2 comments." title="This torrent has 2 comments."/><a href="/user/EtHD"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 1.73&nbsp;GiB, ULed by <a class="detDesc" href="/user/EtHD/" title="Browse EtHD">EtHD</a></font>
</td>
<td align="right">130</td>
<td align="right">9</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12872025/The_Walking_Dead_(2015)_S06E08_1080p_WEB-DL_NL_Subs_SAM_2LT" class="detLink" title="Details for The Walking Dead (2015) S06E08 1080p WEB-DL NL Subs SAM 2LT">The Walking Dead (2015) S06E08 1080p WEB-DL NL Subs SAM 2LT</a>
</div>
<a href="magnet:?xt=urn:btih:4b703863abe6feaade8a445e008006da3f3ae721&dn=The+Walking+Dead+%282015%29+S06E08+1080p+WEB-DL+NL+Subs+SAM+2LT&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo0YjcwMzg2M2FiZTZmZWFhZGU4YTQ0NWUwMDgwMDZkYTNmM2FlNzIxJmRuPVRoZStXYWxraW5nK0RlYWQrJTI4MjAxNSUyOStTMDZFMDgrMTA4MHArV0VCLURMK05MK1N1YnMrU0FNKzJMVCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The Walking Dead (2015) S06E08 1080p WEB-DL NL Subs SAM 2LT&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 3 comments." title="This torrent has 3 comments."/><a href="/user/Sammynet"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 1.73&nbsp;GiB, ULed by <a class="detDesc" href="/user/Sammynet/" title="Browse Sammynet">Sammynet</a></font>
</td>
<td align="right">73</td>
<td align="right">4</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13159366/The_Walking_Dead_S06E08_HDTV_720p_H264_[StB]" class="detLink" title="Details for The Walking Dead S06E08 HDTV 720p H264 [StB]">The Walking Dead S06E08 HDTV 720p H264 [StB]</a>
</div>
<a href="magnet:?xt=urn:btih:a462b25a9dc42a5e572a14c6f9fa735fa8c7173f&dn=The+Walking+Dead+S06E08+HDTV+720p+H264+%5BStB%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDphNDYyYjI1YTlkYzQyYTVlNTcyYTE0YzZmOWZhNzM1ZmE4YzcxNzNmJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4K0hEVFYrNzIwcCtIMjY0KyU1QlN0QiU1RCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The Walking Dead S06E08 HDTV 720p H264 [StB]&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 01-07&nbsp;03:15, Size 351.9&nbsp;MiB, ULed by <a class="detDesc" href="/user/KaGoo/" title="Browse KaGoo">KaGoo</a></font>
</td>
<td align="right">53</td>
<td align="right">0</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12875325/The_Walking_Dead_S06E08_1080p_WEB-DL_Dual_Audio" class="detLink" title="Details for The Walking Dead S06E08 1080p WEB-DL Dual Audio">The Walking Dead S06E08 1080p WEB-DL Dual Audio</a>
</div>
<a href="magnet:?xt=urn:btih:5404c0540272178d6319a1f83580e62f93392dbd&dn=The+Walking+Dead+S06E08+1080p+WEB-DL+Dual+Audio&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo1NDA0YzA1NDAyNzIxNzhkNjMxOWExZjgzNTgwZTYyZjkzMzkyZGJkJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzEwODBwK1dFQi1ETCtEdWFsK0F1ZGlvJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The Walking Dead S06E08 1080p WEB-DL Dual Audio&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-01&nbsp;2015, Size 1.79&nbsp;GiB, ULed by <a class="detDesc" href="/user/Brasil567/" title="Browse Brasil567">Brasil567</a></font>
</td>
<td align="right">35</td>
<td align="right">8</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12870212/The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-ETRG" class="detLink" title="Details for The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-ETRG">The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-ETRG</a>
</div>
<a href="magnet:?xt=urn:btih:ba2c7b5c32a04a930223db877d830827ca53499f&dn=The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-ETRG&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpiYTJjN2I1YzMyYTA0YTkzMDIyM2RiODc3ZDgzMDgyN2NhNTM0OTlmJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjcyMHAuSERUVi54MjY0LkFBQy1FVFJHJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-ETRG&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/e.ozlem"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 328.16&nbsp;MiB, ULed by <a class="detDesc" href="/user/e.ozlem/" title="Browse e.ozlem">e.ozlem</a></font>
</td>
<td align="right">34</td>
<td align="right">4</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12870697/The_Walking_Dead_S06E08_VOSTFR_HDTV" class="detLink" title="Details for The Walking Dead S06E08 VOSTFR HDTV">The Walking Dead S06E08 VOSTFR HDTV</a>
</div>
<a href="magnet:?xt=urn:btih:c6d0bbc11c562d5cab766b5f43b6e53d07679ee9&dn=The+Walking+Dead+S06E08+VOSTFR+HDTV&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpjNmQwYmJjMTFjNTYyZDVjYWI3NjZiNWY0M2I2ZTUzZDA3Njc5ZWU5JmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4K1ZPU1RGUitIRFRWJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The Walking Dead S06E08 VOSTFR HDTV&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 1 comments." title="This torrent has 1 comments."/><a href="/user/annuaireweb"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 350.45&nbsp;MiB, ULed by <a class="detDesc" href="/user/annuaireweb/" title="Browse annuaireweb">annuaireweb</a></font>
</td>
<td align="right">21</td>
<td align="right">2</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12895395/The.Walking.Dead.S06E08.2015.720p.Dual.Audio.SenhoreSTorrenT" class="detLink" title="Details for The.Walking.Dead.S06E08.2015.720p.Dual.Audio.SenhoreSTorrenT">The.Walking.Dead.S06E08.2015.720p.Dual.Audio.SenhoreSTorrenT</a>
</div>
<a href="magnet:?xt=urn:btih:4ee8bf72fadec68ab71dc91b0b28d638c6b5af25&dn=The.Walking.Dead.S06E08.2015.720p.Dual.Audio.SenhoreSTorrenT&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo0ZWU4YmY3MmZhZGVjNjhhYjcxZGM5MWIwYjI4ZDYzOGM2YjVhZjI1JmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjIwMTUuNzIwcC5EdWFsLkF1ZGlvLlNlbmhvcmVTVG9ycmVuVCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The.Walking.Dead.S06E08.2015.720p.Dual.Audio.SenhoreSTorrenT&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/SenhoreS"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-03&nbsp;2015, Size 615.69&nbsp;MiB, ULed by <a class="detDesc" href="/user/SenhoreS/" title="Browse SenhoreS">SenhoreS</a></font>
</td>
<td align="right">21</td>
<td align="right">2</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869677/The.Walking.Dead.S06E08.HDTV.x264-KILLERS.[VTV].mp4" class="detLink" title="Details for The.Walking.Dead.S06E08.HDTV.x264-KILLERS.[VTV].mp4">The.Walking.Dead.S06E08.HDTV.x264-KILLERS.[VTV].mp4</a>
</div>
<a href="magnet:?xt=urn:btih:0267f5eba55d7eb00b7e63f05ac15c08435d7aaa&dn=The.Walking.Dead.S06E08.HDTV.x264-KILLERS.%5BVTV%5D.mp4&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDowMjY3ZjVlYmE1NWQ3ZWIwMGI3ZTYzZjA1YWMxNWMwODQzNWQ3YWFhJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LkhEVFYueDI2NC1LSUxMRVJTLiU1QlZUViU1RC5tcDQmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The.Walking.Dead.S06E08.HDTV.x264-KILLERS.[VTV].mp4&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/VTV"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 395.76&nbsp;MiB, ULed by <a class="detDesc" href="/user/VTV/" title="Browse VTV">VTV</a></font>
</td>
<td align="right">20</td>
<td align="right">0</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12871194/The_Walking_Dead_S06E08_1080p_HDTV_x264_Legendado" class="detLink" title="Details for The Walking Dead S06E08 1080p HDTV x264 Legendado">The Walking Dead S06E08 1080p HDTV x264 Legendado</a>
</div>
<a href="magnet:?xt=urn:btih:2d210a7f2d2cb5a32c384572126c096955f5222b&dn=The+Walking+Dead+S06E08+1080p+HDTV+x264+Legendado&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDoyZDIxMGE3ZjJkMmNiNWEzMmMzODQ1NzIxMjZjMDk2OTU1ZjUyMjJiJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzEwODBwK0hEVFYreDI2NCtMZWdlbmRhZG8mdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The Walking Dead S06E08 1080p HDTV x264 Legendado&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 2.58&nbsp;GiB, ULed by <a class="detDesc" href="/user/Brasil567/" title="Browse Brasil567">Brasil567</a></font>
</td>
<td align="right">18</td>
<td align="right">1</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869901/The_Walking_Dead_S06E08_720p_HDTV_x265_HEVC_250MB_-_ShAaNiG" class="detLink" title="Details for The Walking Dead S06E08 720p HDTV x265 HEVC 250MB - ShAaNiG">The Walking Dead S06E08 720p HDTV x265 HEVC 250MB - ShAaNiG</a>
</div>
<a href="magnet:?xt=urn:btih:84af8a6f982983d1746e7b040789b76b0cb8e773&dn=The+Walking+Dead+S06E08+720p+HDTV+x265+HEVC+250MB+-+ShAaNiG&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo4NGFmOGE2Zjk4Mjk4M2QxNzQ2ZTdiMDQwNzg5Yjc2YjBjYjhlNzczJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzcyMHArSERUVit4MjY1K0hFVkMrMjUwTUIrLStTaEFhTmlHJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The Walking Dead S06E08 720p HDTV x265 HEVC 250MB - ShAaNiG&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 1 comments." title="This torrent has 1 comments."/><a href="/user/ShAaNiG"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 250.13&nbsp;MiB, ULed by <a class="detDesc" href="/user/ShAaNiG/" title="Browse ShAaNiG">ShAaNiG</a></font>
</td>
<td align="right">15</td>
<td align="right">4</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12875600/The_Walking_Dead_S06E08_1080p_WEB-DL_x264-Belex_-_Dual_Audio" class="detLink" title="Details for The Walking Dead S06E08 1080p WEB-DL x264-Belex - Dual Audio">The Walking Dead S06E08 1080p WEB-DL x264-Belex - Dual Audio</a>
</div>
<a href="magnet:?xt=urn:btih:23215477df25c7559c151b6ae0478b00ee706baa&dn=The+Walking+Dead+S06E08+1080p+WEB-DL+x264-Belex+-+Dual+Audio&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDoyMzIxNTQ3N2RmMjVjNzU1OWMxNTFiNmFlMDQ3OGIwMGVlNzA2YmFhJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzEwODBwK1dFQi1ETCt4MjY0LUJlbGV4Ky0rRHVhbCtBdWRpbyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The Walking Dead S06E08 1080p WEB-DL x264-Belex - Dual Audio&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/jarcsm"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-01&nbsp;2015, Size 1.79&nbsp;GiB, ULed by <a class="detDesc" href="/user/jarcsm/" title="Browse jarcsm">jarcsm</a></font>
</td>
<td align="right">12</td>
<td align="right">5</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12870679/The_Walking_Dead_S06E08_VOSTFR_BluRay_720p_HDTV" class="detLink" title="Details for The Walking Dead S06E08 VOSTFR BluRay 720p HDTV">The Walking Dead S06E08 VOSTFR BluRay 720p HDTV</a>
</div>
<a href="magnet:?xt=urn:btih:cd73e8a684dc0d496f9e50c9d1be446ec76ca305&dn=The+Walking+Dead+S06E08+VOSTFR+BluRay+720p+HDTV&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpjZDczZThhNjg0ZGMwZDQ5NmY5ZTUwYzlkMWJlNDQ2ZWM3NmNhMzA1JmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4K1ZPU1RGUitCbHVSYXkrNzIwcCtIRFRWJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The Walking Dead S06E08 VOSTFR BluRay 720p HDTV&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/annuaireweb"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 1.24&nbsp;GiB, ULed by <a class="detDesc" href="/user/annuaireweb/" title="Browse annuaireweb">annuaireweb</a></font>
</td>
<td align="right">11</td>
<td align="right">2</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12873748/The_Walking_Dead_S06E08_720p_5.1Ch_Web-DL_ReEnc_DeeJayAhmed" class="detLink" title="Details for The Walking Dead S06E08 720p 5.1Ch Web-DL ReEnc DeeJayAhmed">The Walking Dead S06E08 720p 5.1Ch Web-DL ReEnc DeeJayAhmed</a>
</div>
<a href="magnet:?xt=urn:btih:b2e89c50c388d814093eb5a65a33dee6f524a5db&dn=The+Walking+Dead+S06E08+720p+5.1Ch+Web-DL+ReEnc+DeeJayAhmed&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpiMmU4OWM1MGMzODhkODE0MDkzZWI1YTY1YTMzZGVlNmY1MjRhNWRiJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzcyMHArNS4xQ2grV2ViLURMK1JlRW5jK0RlZUpheUFobWVkJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The Walking Dead S06E08 720p 5.1Ch Web-DL ReEnc DeeJayAhmed&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/DeeJayPirate"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 361.26&nbsp;MiB, ULed by <a class="detDesc" href="/user/DeeJayPirate/" title="Browse DeeJayPirate">DeeJayPirate</a></font>
</td>
<td align="right">8</td>
<td align="right">0</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869759/The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-SS_-__SPARROW__-" class="detLink" title="Details for The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-SS -={SPARROW}=-">The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-SS -={SPARROW}=-</a>
</div>
<a href="magnet:?xt=urn:btih:2fca8413c4ce32c2e5417e2f7235db3993bfe01c&dn=The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-SS+-%3D%7BSPARROW%7D%3D-&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDoyZmNhODQxM2M0Y2UzMmMyZTU0MTdlMmY3MjM1ZGIzOTkzYmZlMDFjJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjcyMHAuSERUVi54MjY0LkFBQy1TUystJTNEJTdCU1BBUlJPVyU3RCUzRC0mdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The.Walking.Dead.S06E08.720p.HDTV.x264.AAC-SS -={SPARROW}=-&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 1 comments." title="This torrent has 1 comments."/><a href="/user/SS132203"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 328.11&nbsp;MiB, ULed by <a class="detDesc" href="/user/SS132203/" title="Browse SS132203">SS132203</a></font>
</td>
<td align="right">7</td>
<td align="right">3</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12869875/The.Walking.Dead.S06E08.400p.266mb.HDTV.x264-][_Start_to_Finish_" class="detLink" title="Details for The.Walking.Dead.S06E08.400p.266mb.HDTV.x264-][ Start to Finish ">The.Walking.Dead.S06E08.400p.266mb.HDTV.x264-][ Start to Finish </a>
</div>
<a href="magnet:?xt=urn:btih:958ae00404cb611311cca95456135d7ab612bf30&dn=The.Walking.Dead.S06E08.400p.266mb.HDTV.x264-%5D%5B+Start+to+Finish+&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo5NThhZTAwNDA0Y2I2MTEzMTFjY2E5NTQ1NjEzNWQ3YWI2MTJiZjMwJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjQwMHAuMjY2bWIuSERUVi54MjY0LSU1RCU1QitTdGFydCt0bytGaW5pc2grJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.400p.266mb.HDTV.x264-][ Start to Finish &i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 1 comments." title="This torrent has 1 comments."/><a href="/user/psspss"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 266.1&nbsp;MiB, ULed by <a class="detDesc" href="/user/psspss/" title="Browse psspss">psspss</a></font>
</td>
<td align="right">5</td>
<td align="right">2</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12871161/The_Walking_Dead_S06E08_720p_HDTV_x264_Legendado" class="detLink" title="Details for The Walking Dead S06E08 720p HDTV x264 Legendado">The Walking Dead S06E08 720p HDTV x264 Legendado</a>
</div>
<a href="magnet:?xt=urn:btih:e392b5475854191f96cdefdbc072e1e5d216e762&dn=The+Walking+Dead+S06E08+720p+HDTV+x264+Legendado&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDplMzkyYjU0NzU4NTQxOTFmOTZjZGVmZGJjMDcyZTFlNWQyMTZlNzYyJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzcyMHArSERUVit4MjY0K0xlZ2VuZGFkbyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The Walking Dead S06E08 720p HDTV x264 Legendado&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 1.24&nbsp;GiB, ULed by <a class="detDesc" href="/user/Brasil567/" title="Browse Brasil567">Brasil567</a></font>
</td>
<td align="right">5</td>
<td align="right">0</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12888537/The_Walking_Dead_Season_6_S06E08_720p_Web-dl_x264" class="detLink" title="Details for The Walking Dead Season 6 S06E08 720p Web-dl x264">The Walking Dead Season 6 S06E08 720p Web-dl x264</a>
</div>
<a href="magnet:?xt=urn:btih:def97b34a0069df6bb16bc16e993323cf714ce26&dn=The+Walking+Dead+Season+6+S06E08+720p+Web-dl+x264&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkZWY5N2IzNGEwMDY5ZGY2YmIxNmJjMTZlOTkzMzIzY2Y3MTRjZTI2JmRuPVRoZStXYWxraW5nK0RlYWQrU2Vhc29uKzYrUzA2RTA4KzcyMHArV2ViLWRsK3gyNjQmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The Walking Dead Season 6 S06E08 720p Web-dl x264&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/Jodo1210"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-02&nbsp;2015, Size 275.81&nbsp;MiB, ULed by <a class="detDesc" href="/user/Jodo1210/" title="Browse Jodo1210">Jodo1210</a></font>
</td>
<td align="right">5</td>
<td align="right">0</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12875604/The_Walking_Dead_S06E08_720p_WEB-DL_x264-Belex_-_Dual_Audio_-_Du" class="detLink" title="Details for The Walking Dead S06E08 720p WEB-DL x264-Belex - Dual Audio - Du">The Walking Dead S06E08 720p WEB-DL x264-Belex - Dual Audio - Du</a>
</div>
<a href="magnet:?xt=urn:btih:47325ec4b5ecf139a5dcba84d3a3f21bc5a70c79&dn=The+Walking+Dead+S06E08+720p+WEB-DL+x264-Belex+-+Dual+Audio+-+Du&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo0NzMyNWVjNGI1ZWNmMTM5YTVkY2JhODRkM2EzZjIxYmM1YTcwYzc5JmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4KzcyMHArV0VCLURMK3gyNjQtQmVsZXgrLStEdWFsK0F1ZGlvKy0rRHUmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The Walking Dead S06E08 720p WEB-DL x264-Belex - Dual Audio - Du&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/jarcsm"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-01&nbsp;2015, Size 1.45&nbsp;GiB, ULed by <a class="detDesc" href="/user/jarcsm/" title="Browse jarcsm">jarcsm</a></font>
</td>
<td align="right">4</td>
<td align="right">2</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12889038/The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[cttv]" class="detLink" title="Details for The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[cttv]">The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[cttv]</a>
</div>
<a href="magnet:?xt=urn:btih:d72b333a555679ea0a0d00bc53c75cec8219a218&dn=The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS%5Bcttv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkNzJiMzMzYTU1NTY3OWVhMGEwZDAwYmM1M2M3NWNlYzgyMTlhMjE4JmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjcyMHAuSERUVi54MjY0LUtJTExFUlMlNUJjdHR2JTVEJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.720p.HDTV.x264-KILLERS[cttv]&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/maximersk"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 12-02&nbsp;2015, Size 1.74&nbsp;GiB, ULed by <a class="detDesc" href="/user/maximersk/" title="Browse maximersk">maximersk</a></font>
</td>
<td align="right">3</td>
<td align="right">1</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12870988/The_Walking_Dead_S06E08_-_Legendado_Portugues_Brasil_-_Al3xandre" class="detLink" title="Details for The Walking Dead S06E08 - Legendado Portugues Brasil - Al3xandre">The Walking Dead S06E08 - Legendado Portugues Brasil - Al3xandre</a>
</div>
<a href="magnet:?xt=urn:btih:ddcdd745721cc9710387df5d76e414ca8bfbc150&dn=The+Walking+Dead+S06E08+-+Legendado+Portugues+Brasil+-+Al3xandre&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkZGNkZDc0NTcyMWNjOTcxMDM4N2RmNWQ3NmU0MTRjYThiZmJjMTUwJmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4Ky0rTGVnZW5kYWRvK1BvcnR1Z3VlcytCcmFzaWwrLStBbDN4YW5kcmUmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The Walking Dead S06E08 - Legendado Portugues Brasil - Al3xandre&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 455.13&nbsp;MiB, ULed by <a class="detDesc" href="/user/walkingdeadlegendado/" title="Browse walkingdeadlegendado">walkingdeadlegendado</a></font>
</td>
<td align="right">2</td>
<td align="right">1</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12872942/The.Walking.Dead.S06E08.1080p.WEB-DL.5.1.opus.x265.bluury" class="detLink" title="Details for The.Walking.Dead.S06E08.1080p.WEB-DL.5.1.opus.x265.bluury">The.Walking.Dead.S06E08.1080p.WEB-DL.5.1.opus.x265.bluury</a>
</div>
<a href="magnet:?xt=urn:btih:d59cf6269c1ad3d5ddcac919df721cc9b402b38a&dn=The.Walking.Dead.S06E08.1080p.WEB-DL.5.1.opus.x265.bluury&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkNTljZjYyNjljMWFkM2Q1ZGRjYWM5MTlkZjcyMWNjOWI0MDJiMzhhJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjEwODBwLldFQi1ETC41LjEub3B1cy54MjY1LmJsdXVyeSZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The.Walking.Dead.S06E08.1080p.WEB-DL.5.1.opus.x265.bluury&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 277.79&nbsp;MiB, ULed by <a class="detDesc" href="/user/ravarage/" title="Browse ravarage">ravarage</a></font>
</td>
<td align="right">2</td>
<td align="right">1</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12871147/The_Walking_Dead_S06E08_HDTV_x264_Legendado" class="detLink" title="Details for The Walking Dead S06E08 HDTV x264 Legendado">The Walking Dead S06E08 HDTV x264 Legendado</a>
</div>
<a href="magnet:?xt=urn:btih:fb848f7e2bca3b5fc07ac05f0c9c6695912993d5&dn=The+Walking+Dead+S06E08+HDTV+x264+Legendado&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpmYjg0OGY3ZTJiY2EzYjVmYzA3YWMwNWYwYzljNjY5NTkxMjk5M2Q1JmRuPVRoZStXYWxraW5nK0RlYWQrUzA2RTA4K0hEVFYreDI2NCtMZWdlbmRhZG8mdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The Walking Dead S06E08 HDTV x264 Legendado&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 339.75&nbsp;MiB, ULed by <a class="detDesc" href="/user/Brasil567/" title="Browse Brasil567">Brasil567</a></font>
</td>
<td align="right">1</td>
<td align="right">1</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12872762/The.Walking.Dead.S06E08.XviD-AFG" class="detLink" title="Details for The.Walking.Dead.S06E08.XviD-AFG">The.Walking.Dead.S06E08.XviD-AFG</a>
</div>
<a href="magnet:?xt=urn:btih:7849113671b1d35af06b97e4d0c20135609390db&dn=The.Walking.Dead.S06E08.XviD-AFG&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo3ODQ5MTEzNjcxYjFkMzVhZjA2Yjk3ZTRkMGMyMDEzNTYwOTM5MGRiJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4Llh2aUQtQUZHJnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIub3BlbmJpdHRvcnJlbnQuY29tJTNBODAmdHI9dWRwJTNBJTJGJTJGb3Blbi5kZW1vbmlpLmNvbSUzQTEzMzcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5jb3BwZXJzdXJmZXIudGslM0E2OTY5JnRyPXVkcCUzQSUyRiUyRmV4b2R1cy5kZXN5bmMuY29tJTNBNjk2OQ==&t=The.Walking.Dead.S06E08.XviD-AFG&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/TvTeam"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 416.04&nbsp;MiB, ULed by <a class="detDesc" href="/user/TvTeam/" title="Browse TvTeam">TvTeam</a></font>
</td>
<td align="right">1</td>
<td align="right">0</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12873705/The.Walking.Dead.S06E08.Post.Credits.Scene" class="detLink" title="Details for The.Walking.Dead.S06E08.Post.Credits.Scene">The.Walking.Dead.S06E08.Post.Credits.Scene</a>
</div>
<a href="magnet:?xt=urn:btih:ec628f8dc4adf15f4c94a7098484db422d8c4596&dn=The.Walking.Dead.S06E08.Post.Credits.Scene&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDplYzYyOGY4ZGM0YWRmMTVmNGM5NGE3MDk4NDg0ZGI0MjJkOGM0NTk2JmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LlBvc3QuQ3JlZGl0cy5TY2VuZSZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=The.Walking.Dead.S06E08.Post.Credits.Scene&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 25.9&nbsp;MiB, ULed by <a class="detDesc" href="/user/Jay2Eight/" title="Browse Jay2Eight">Jay2Eight</a></font>
</td>
<td align="right">1</td>
<td align="right">0</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/12872957/The.Walking.Dead.S06E08.480p.x264-mSD" class="detLink" title="Details for The.Walking.Dead.S06E08.480p.x264-mSD">The.Walking.Dead.S06E08.480p.x264-mSD</a>
</div>
<a href="magnet:?xt=urn:btih:46e25721620d705bbd8da295f6bd935c96d9158f&dn=The.Walking.Dead.S06E08.480p.x264-mSD&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo0NmUyNTcyMTYyMGQ3MDViYmQ4ZGEyOTVmNmJkOTM1Yzk2ZDkxNThmJmRuPVRoZS5XYWxraW5nLkRlYWQuUzA2RTA4LjQ4MHAueDI2NC1tU0QmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=The.Walking.Dead.S06E08.480p.x264-mSD&i=" target="_blank" title="Stream using Torrents-Time"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/TvTeam"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 11-30&nbsp;2015, Size 205.84&nbsp;MiB, ULed by <a class="detDesc" href="/user/TvTeam/" title="Browse TvTeam">TvTeam</a></font>
</td>
<td align="right">0</td>
<td align="right">1</td>
</tr>
</table>
</div>
<div align="center"></div>
<div class="ads" id="sky-banner">
</div>
</div></div></div>
<div id="foot" style="text-align:center;margin-top:1em;">
<p>
<br/>
</div>
</body>
</html>
'''

from bs4 import BeautifulSoup

soup = BeautifulSoup(data, 'html5lib')
links = soup.table.tbody.findAll('tr')

for link in links:
    columns = link.findAll('td')
    print columns[1].div.text  # name
    print columns[1].select('div + a')[0]["href"]  # magnet
    print columns[1].font.text.split(',')[1].replace('Size', '')  # size
    print columns[2].text  # seed
    print columns[3].text  # leech
    print "************************"
